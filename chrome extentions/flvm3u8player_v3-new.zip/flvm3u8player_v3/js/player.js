document.addEventListener('DOMContentLoaded', function() {
//  const urlParams = new URLSearchParams(window.location.search);
//  const videoUrl = urlParams.get('url');
  // 获取视频URL - 支持hash和query参数
  let videoUrl = '';
  const urlParams = new URLSearchParams(window.location.search);
  const queryUrl = urlParams.get('url');
  const hashUrl = window.location.hash.substring(1);
  
  // 优先使用query参数，如果没有则使用hash
  videoUrl = queryUrl || hashUrl;  
  // DOM元素
  const videoPlayer = document.getElementById('videoPlayer');
  const videoInfo = document.getElementById('videoInfo');
  const backBtn = document.getElementById('backBtn');
  const playPauseBtn = document.getElementById('playPauseBtn');
  const progress = document.getElementById('progress');
  const progressBar = document.getElementById('progressBar');
  const timeDisplay = document.getElementById('time');
  const volumeBtn = document.getElementById('volumeBtn');
  const volumeSlider = document.getElementById('volumeSlider');
  const volumeProgress = document.getElementById('volumeProgress');
  const fullscreenBtn = document.getElementById('fullscreenBtn');
  const loading = document.getElementById('loading');
  const errorMessage = document.getElementById('errorMessage');
  const controls = document.getElementById('controls');
  
  // 播放列表相关元素
  const playlistBtn = document.getElementById('playlistBtn');
  const playlistContainer = document.getElementById('playlist-container');
  const closePlaylistBtn = document.getElementById('closePlaylistBtn');
  const playlistItems = document.getElementById('playlist-items');
  const playlistSearchInput = document.getElementById('playlist-search-input');
  const clearSearchBtn = document.getElementById('clearSearchBtn');
  
  let player = null;
  let isPlaying = false;
  let controlsTimeout;
  let videoContainer = document.querySelector('.video-container');

  // 播放列表相关变量
  let currentPlaylist = [];
  let currentPlaylistIndex = -1;
  let isM3UPlaylist = false;
  let baseUrl = '';

  // 创建视频信息按钮和弹窗
  const infoBtn = document.createElement('button');
  infoBtn.className = 'info-btn';
  infoBtn.innerHTML = 'ℹ';
  infoBtn.style.cssText = 'background:none; border:none; color:white; cursor:pointer; margin-left:10px;';
  document.querySelector('.volume-container').insertAdjacentElement('afterend', infoBtn);

  const infoPanel = document.createElement('div');
  infoPanel.className = 'info-panel';
  infoPanel.style.cssText = 'display:none; position:absolute; bottom:60px; right:10px; background:rgba(0,0,0,0.8); padding:10px; border-radius:4px; font-size:12px;';
  videoContainer.appendChild(infoPanel);

  // 从存储中加载音量设置
  chrome.storage.local.get(['volume'], function(result) {
    if (result.volume !== undefined) {
      videoPlayer.volume = result.volume;
      volumeProgress.style.width = (result.volume * 100) + '%';
      updateVolumeIcon();
    }
  });

  // 存储视频流信息的对象 - 改进点1：统一信息存储
  let streamInfo = {
    resolution: '未知',
    bitrate: '未知',
    codec: '未知',
    fps: '未知',
    duration: '未知',
    type: '未知'
  };
  
  // 信息更新间隔（毫秒）- 改进点2：定期更新机制
  const INFO_UPDATE_INTERVAL = 5000;
  let infoUpdateTimer = null;
  
  function startInfoUpdateTimer() {
    // 清除可能存在的旧定时器
    if (infoUpdateTimer) {
      clearInterval(infoUpdateTimer);
    }
    
    // 设置新的定时器，定期更新视频信息
    infoUpdateTimer = setInterval(() => {
      updateVideoInfo();
    }, INFO_UPDATE_INTERVAL);
  }
  
  function stopInfoUpdateTimer() {
    if (infoUpdateTimer) {
      clearInterval(infoUpdateTimer);
      infoUpdateTimer = null;
    }
  }

  function initPlayer() {
    if (!videoUrl) {
      showError('无效的视频链接');
      return;
    }
    
    videoInfo.textContent = decodeURIComponent(videoUrl);
    showLoading(true);
    
    // 保存基础URL，用于解析相对路径
    try {
      const url = new URL(videoUrl);
      baseUrl = url.href.substring(0, url.href.lastIndexOf('/') + 1);
    } catch (e) {
      console.error('解析URL失败:', e);
      baseUrl = '';
    }
    
    // 使用正则表达式匹配.flv、.m3u8或.m3u，忽略后面的参数和锚点
    const lowerUrl = videoUrl.toLowerCase();
    if (/\.flv([?#].*)?$/.test(lowerUrl)) {
      streamInfo.type = 'FLV';
      initFlvPlayer();
    } else if (/\.m3u8([?#].*)?$/.test(lowerUrl)) {
      streamInfo.type = 'HLS';
      initHlsPlayer();
    } else if (/\.m3u([?#].*)?$/.test(lowerUrl)) {
      streamInfo.type = 'M3U';
      initM3UPlaylist();
    } else {
      streamInfo.type = '原生';
      initNativePlayer();
    }
    
    // 启动定期更新信息的定时器（对于直播流特别有用）
    startInfoUpdateTimer();
  }
  
  // 添加 M3U 播放列表初始化函数
  function initM3UPlaylist() {
    isM3UPlaylist = true;
    
    // 创建 M3U 解析器
    const parser = new M3UParser();
    
    // 解析 M3U 文件
    parser.parseFromUrl(videoUrl)
      .then(playlist => {
        if (playlist.length === 0) {
          showError('播放列表为空');
          return;
        }
        
        // 处理相对路径URL
        playlist.forEach(item => {
          if (!item.url.startsWith('http') && !item.url.startsWith('//')) {
            item.url = M3UParser.resolveUrl(baseUrl, item.url);
          }
        });
        
        currentPlaylist = playlist;
        renderPlaylist();
        
        // 播放第一个项目
        playPlaylistItem(0);
        
        // 显示播放列表
        togglePlaylist(true);
      })
      .catch(error => {
        console.error('解析 M3U 文件失败:', error);
        showError('解析播放列表失败: ' + error.message);
      });
  }

  // 渲染播放列表
  function renderPlaylist(searchTerm = '') {
    playlistItems.innerHTML = '';
    
    // 转换搜索词为小写，用于不区分大小写的搜索
    const lowerSearchTerm = searchTerm.toLowerCase();
    
    currentPlaylist.forEach((item, index) => {
      const itemElement = document.createElement('div');
      itemElement.className = 'playlist-item';
      if (index === currentPlaylistIndex) {
        itemElement.classList.add('active');
      }
      
      // 获取频道名
      const channelName = item.title || `项目 ${index + 1}`;
      itemElement.textContent = channelName;
      
      // 如果有搜索词，检查是否匹配
      if (searchTerm) {
        if (!channelName.toLowerCase().includes(lowerSearchTerm)) {
          itemElement.classList.add('hidden');
        }
      }
      
      itemElement.addEventListener('click', () => {
        playPlaylistItem(index);
      });
      
      // 为每个项目添加数据属性，便于后续搜索
      itemElement.dataset.index = index;
      itemElement.dataset.channelName = channelName;
      
      playlistItems.appendChild(itemElement);
    });
  }
  
  // 搜索播放列表
  function searchPlaylist(searchTerm) {
    // 更新清除按钮可见性
    if (searchTerm) {
      clearSearchBtn.classList.add('visible');
    } else {
      clearSearchBtn.classList.remove('visible');
    }
    
    // 如果已经渲染了播放列表，直接过滤现有项目
    if (playlistItems.children.length > 0) {
      Array.from(playlistItems.children).forEach(item => {
        const channelName = item.dataset.channelName || '';
        if (searchTerm && !channelName.toLowerCase().includes(searchTerm.toLowerCase())) {
          item.classList.add('hidden');
        } else {
          item.classList.remove('hidden');
        }
      });
    } else {
      // 如果播放列表尚未渲染，重新渲染
      renderPlaylist(searchTerm);
    }
  }
  
  // 清除搜索
  function clearSearch() {
    playlistSearchInput.value = '';
    clearSearchBtn.classList.remove('visible');
    searchPlaylist('');
  }

  // 播放指定索引的播放列表项目
  function playPlaylistItem(index) {
    if (index < 0 || index >= currentPlaylist.length) return;
    
    // 清除之前的错误信息
    errorMessage.style.display = 'none';
    
    currentPlaylistIndex = index;
    const item = currentPlaylist[index];
    
    // 更新播放列表 UI
    document.querySelectorAll('.playlist-item').forEach((el, i) => {
      el.classList.toggle('active', i === index);
    });
    
    // 停止当前播放
    if (player) {
      if (player.destroy) player.destroy();
      player = null;
    }
    
    // 停止信息更新定时器
    stopInfoUpdateTimer();
    
    // 重置流信息
    streamInfo = {
      resolution: '未知',
      bitrate: '未知',
      codec: '未知',
      fps: '未知',
      duration: '未知',
      type: '未知'
    };
    
    // 根据 URL 类型选择播放器
    const itemUrl = item.url;
    const lowerItemUrl = itemUrl.toLowerCase();
    
    videoInfo.textContent = item.title || decodeURIComponent(itemUrl);
    showLoading(true);
   /* 
    if (/\.flv([?#].*)?$/.test(lowerItemUrl)) {
      streamInfo.type = 'FLV';
      initFlvPlayerWithUrl(itemUrl);
    } else if (/\.m3u8([?#].*)?$/.test(lowerItemUrl)) {
      streamInfo.type = 'HLS';
      initHlsPlayerWithUrl(itemUrl);
    } else {
      streamInfo.type = '原生';
      initNativePlayerWithUrl(itemUrl);
    }
    */
    checkAndInitPlayer(itemUrl);
    // 重新启动信息更新定时器
    startInfoUpdateTimer();
  }

  // 检查URL是否需要重定向检测，并初始化播放器
  function checkAndInitPlayer(url) {
    // 先检查URL是否已经是媒体文件
    const lowerUrl = url.toLowerCase();
    if (/\.(flv|m3u8|m3u)([?#].*)?$/.test(lowerUrl)) {
      // 已经是媒体文件，直接初始化播放器
      initPlayerWithUrl(url);
    } else {
      // 可能需要重定向检测
      showLoading(true);
      console.log('检测URL重定向:', url);
      
      chrome.runtime.sendMessage({
        action: "checkRedirect",
        url: url
      }, response => {
        if (response && response.success) {
          const finalUrl = response.finalUrl;
          console.log('重定向后的URL:', finalUrl);
          // 使用最终URL初始化播放器
          initPlayerWithUrl(finalUrl);
        } else {
          // 重定向检测失败，尝试直接使用原始URL
          console.error('重定向检测失败:', response ? response.error : '未知错误');
          initPlayerWithUrl(url);
        }
      });
    }
  }
  
  // 根据URL类型初始化播放器
  function initPlayerWithUrl(url) {
    const lowerUrl = url.toLowerCase();
    if (/\.flv([?#].*)?$/.test(lowerUrl)) {
      initFlvPlayerWithUrl(url);
    } else if (/\.m3u8([?#].*)?$/.test(lowerUrl)) {
      initHlsPlayerWithUrl(url);
    } else if (/\.m3u([?#].*)?$/.test(lowerUrl)) {
      initM3UPlaylistWithUrl(url);
    } else {
      initNativePlayerWithUrl(url);
    }
  }  
  
  function initFlvPlayer() {
    initFlvPlayerWithUrl(videoUrl);
  }
  
  function initFlvPlayerWithUrl(url) {
    if (flvjs.isSupported()) {
      player = flvjs.createPlayer({
        type: 'flv',
        url: url
      });
      player.attachMediaElement(videoPlayer);
      player.load();
      
      // 改进点3：FLV流信息增强 - 监听元数据事件
      player.on(flvjs.Events.METADATA_ARRIVED, function(metadata) {
        console.log('FLV Metadata:', metadata);
        
        // 从元数据中提取视频信息
        if (metadata && metadata.onMetaData) {
          const meta = metadata.onMetaData;
          
          if (meta.width && meta.height) {
            streamInfo.resolution = `${meta.width}x${meta.height}`;
          }
          
          if (meta.videodatarate) {
            streamInfo.bitrate = `${Math.round(meta.videodatarate)} Kbps`;
          }
          
          if (meta.videocodecid) {
            // FLV编码ID映射
            const codecMap = {
              7: 'AVC/H.264',
              12: 'HEVC/H.265',
              8: 'VP8',
              9: 'VP9'
            };
            streamInfo.codec = codecMap[meta.videocodecid] || `未知(${meta.videocodecid})`;
          }
          
          if (meta.framerate) {
            streamInfo.fps = `${Math.round(meta.framerate)} fps`;
          }
          
          if (meta.duration) {
            streamInfo.duration = formatTime(meta.duration);
          }
          
          // 更新显示
          updateInfoPanel();
        }
      });
      
      // 改进点4：FLV流信息增强 - 监听统计信息
      player.on(flvjs.Events.STATISTICS_INFO, function(stats) {
        console.log('FLV Statistics:', stats);
        
        // 更新实时码率信息
        if (stats.currentKBps) {
          const currentBitrate = Math.round(stats.currentKBps * 8);
          streamInfo.bitrate = `${currentBitrate} Kbps`;
          
          // 更新显示
          updateInfoPanel();
        }
      });
      
      player.on(flvjs.Events.ERROR, function(errorType, errorDetail) {
        console.error('FLV播放错误:', errorType, errorDetail);
        showError('FLV播放错误: ' + errorType);
        stopInfoUpdateTimer();
      });
      
      videoPlayer.addEventListener('loadedmetadata', function() {
        showLoading(false);
        updateVideoInfo();
        play();
      });
      
      videoPlayer.addEventListener('error', function() {
        showError('视频加载失败');
        stopInfoUpdateTimer();
      });
    } else {
      showError('您的浏览器不支持FLV播放');
      stopInfoUpdateTimer();
    }
  }
  
  function initHlsPlayer() {
    initHlsPlayerWithUrl(videoUrl);
  }
  
  function initHlsPlayerWithUrl(url) {
    if (Hls.isSupported()) {
      player = new Hls({
        debug: false,
        // 改进点5：HLS流信息增强 - 启用实时码率监控
        capLevelToPlayerSize: true,
        // 启用自适应码率
        autoLevelEnabled: true
      });
      player.loadSource(url);
      player.attachMedia(videoPlayer);
      
      // 改进点6：HLS流信息增强 - 监听清单解析事件
      player.on(Hls.Events.MANIFEST_PARSED, function(event, data) {
        console.log('HLS Manifest:', data);
        showLoading(false);
        
        // 存储可用的质量级别信息
        if (data.levels && data.levels.length > 0) {
          // 获取当前使用的质量级别
          const currentLevel = player.currentLevel >= 0 ? player.currentLevel : player.autoLevelEnabled ? player.autoLevelLast : 0;
          const levelData = data.levels[currentLevel];
          
          if (levelData) {
            if (levelData.width && levelData.height) {
              streamInfo.resolution = `${levelData.width}x${levelData.height}`;
            }
            
            if (levelData.bitrate) {
              streamInfo.bitrate = `${Math.round(levelData.bitrate / 1000)} Kbps`;
            }
            
            if (levelData.videoCodec) {
              streamInfo.codec = levelData.videoCodec;
            }
            
            // 更新显示
            updateInfoPanel();
          }
        }
        
        play();
      });
      
      // 改进点7：HLS流信息增强 - 监听级别切换事件
      player.on(Hls.Events.LEVEL_SWITCHED, function(event, data) {
        console.log('HLS Level Switched:', data);
        
        const levelData = player.levels[data.level];
        if (levelData) {
          if (levelData.width && levelData.height) {
            streamInfo.resolution = `${levelData.width}x${levelData.height}`;
          }
          
          if (levelData.bitrate) {
            streamInfo.bitrate = `${Math.round(levelData.bitrate / 1000)} Kbps`;
          }
          
          // 更新显示
          updateInfoPanel();
        }
      });
      
      // 改进点8：HLS流信息增强 - 监听片段加载事件，用于计算实时码率
      player.on(Hls.Events.FRAG_LOADED, function(event, data) {
        if (data.frag && data.frag.duration && data.stats) {
          const loadTime = data.stats.loading.end - data.stats.loading.start;
          const bytes = data.stats.loaded;
          
          if (loadTime > 0 && bytes > 0) {
            // 计算实时码率 (bits per second)
            const bps = Math.round((bytes * 8) / loadTime);
            streamInfo.bitrate = `${Math.round(bps / 1000)} Kbps`;
            
            // 更新显示
            updateInfoPanel();
          }
        }
      });
      
      // 改进点9：HLS流信息增强 - 监听级别加载事件
      player.on(Hls.Events.LEVEL_LOADED, function(event, data) {
        console.log('HLS Level Loaded:', data);
        
        if (data.details) {
          // 获取总时长
          if (data.details.totalduration) {
            streamInfo.duration = formatTime(data.details.totalduration);
          }
          
          // 获取目标时长和片段数，可用于估算帧率
          if (data.details.targetduration && data.details.fragments && data.details.fragments.length > 0) {
            // 假设每个片段包含targetduration秒的内容，标准HLS通常为30fps
            streamInfo.fps = '30 fps (估计)';
          }
          
          // 更新显示
          updateInfoPanel();
        }
      });
      
      // 添加loadeddata事件监听，确保视频元数据已加载
      videoPlayer.addEventListener('loadeddata', function() {
        // 使用视频元素的原生信息作为备选
        updateVideoInfoFromElement();
      });
      
      player.on(Hls.Events.ERROR, function(event, data) {
        if (data.fatal) {
          console.error('HLS播放错误:', data.type, data.details);
          showError('HLS播放错误: ' + data.details);
          stopInfoUpdateTimer();
        }
      });
    } else if (videoPlayer.canPlayType('application/vnd.apple.mpegurl')) {
      // 原生HLS支持（如Safari）
      videoPlayer.src = url;
      videoPlayer.addEventListener('loadedmetadata', function() {
        showLoading(false);
        play();
      });
      
      videoPlayer.addEventListener('loadeddata', function() {
        // 使用视频元素的原生信息
        updateVideoInfoFromElement();
      });
      
      videoPlayer.addEventListener('error', function() {
        showError('视频加载失败');
        stopInfoUpdateTimer();
      });
    } else {
      showError('您的浏览器不支持HLS播放');
      stopInfoUpdateTimer();
    }
  }
  
  function initNativePlayer() {
    initNativePlayerWithUrl(videoUrl);
  }
  
  function initNativePlayerWithUrl(url) {
    videoPlayer.src = url;
    
    videoPlayer.addEventListener('loadedmetadata', function() {
      showLoading(false);
      updateVideoInfoFromElement();
      play();
    });
    
    videoPlayer.addEventListener('error', function() {
      showError('不支持的视频格式或视频加载失败');
      stopInfoUpdateTimer();
    });
  }
  
  // 改进点10：从视频元素获取基本信息
  function updateVideoInfoFromElement() {
    // 分辨率
    if (videoPlayer.videoWidth && videoPlayer.videoHeight) {
      streamInfo.resolution = `${videoPlayer.videoWidth}x${videoPlayer.videoHeight}`;
    }
    
    // 时长
    if (videoPlayer.duration && !isNaN(videoPlayer.duration)) {
      streamInfo.duration = formatTime(videoPlayer.duration);
    }
    
    // 尝试获取编码信息（仅部分浏览器支持）
    try {
      if (videoPlayer.getVideoPlaybackQuality) {
        const quality = videoPlayer.getVideoPlaybackQuality();
        
        // 尝试计算帧率（不太准确）
        if (quality.totalVideoFrames > 0 && videoPlayer.currentTime > 0) {
          const fps = Math.round(quality.totalVideoFrames / videoPlayer.currentTime);
          if (fps > 0 && fps < 120) { // 合理范围检查
            streamInfo.fps = `${fps} fps (估计)`;
          }
        }
      }
    } catch (e) {
      console.warn('获取视频质量信息失败:', e);
    }
    
    // 尝试使用MediaSource API获取编码信息
    try {
      if (videoPlayer.srcObject && videoPlayer.srcObject.getVideoTracks) {
        const videoTrack = videoPlayer.srcObject.getVideoTracks()[0];
        if (videoTrack && videoTrack.getSettings) {
          const settings = videoTrack.getSettings();
          
          if (settings.width && settings.height) {
            streamInfo.resolution = `${settings.width}x${settings.height}`;
          }
          
          if (settings.frameRate) {
            streamInfo.fps = `${Math.round(settings.frameRate)} fps`;
          }
        }
      }
    } catch (e) {
      console.warn('获取MediaSource信息失败:', e);
    }
    
    // 更新显示
    updateInfoPanel();
  }
  
  // 改进点11：尝试从MediaCapabilities API获取编解码器信息
  function tryGetCodecInfo() {
    if ('mediaCapabilities' in navigator) {
      // 尝试常见的编解码器配置
      const configurations = [
        { type: 'file', video: { contentType: 'video/mp4; codecs="avc1.42E01E"' } },
        { type: 'file', video: { contentType: 'video/mp4; codecs="hev1.1.6.L93.B0"' } },
        { type: 'file', video: { contentType: 'video/webm; codecs="vp9"' } }
      ];
      
      // 检查当前播放的是哪种编解码器
      Promise.all(configurations.map(config => 
        navigator.mediaCapabilities.decodingInfo(config)
      )).then(results => {
        results.forEach((result, index) => {
          if (result.supported && result.smooth) {
            // 提取编解码器信息
            const codec = configurations[index].video.contentType.split('codecs="')[1].split('"')[0];
            console.log('可能的编解码器:', codec);
            
            // 如果还没有编解码器信息，使用这个
            if (streamInfo.codec === '未知') {
              streamInfo.codec = codec;
              updateInfoPanel();
            }
          }
        });
      }).catch(err => {
        console.warn('MediaCapabilities API 错误:', err);
      });
    }
  }
  
  // 改进点12：更新视频信息面板
  function updateInfoPanel() {
    const info = [];
    
    info.push(`类型: ${streamInfo.type}`);
    info.push(`分辨率: ${streamInfo.resolution}`);
    info.push(`码率: ${streamInfo.bitrate}`);
    info.push(`编码: ${streamInfo.codec}`);
    info.push(`帧率: ${streamInfo.fps}`);
    
    if (streamInfo.duration !== '未知') {
      info.push(`时长: ${streamInfo.duration}`);
    }
    
    // 如果是播放列表，显示当前项目信息
    if (isM3UPlaylist && currentPlaylistIndex >= 0) {
      info.push(`播放列表: ${currentPlaylistIndex + 1}/${currentPlaylist.length}`);
    }
    
    infoPanel.innerHTML = info.join('<br>');
  }
  
  // 改进点13：综合更新视频信息的方法
  function updateVideoInfo() {
    // 首先尝试从播放器特定API获取信息
    if (player) {
      if (streamInfo.type === 'HLS' && player.levels) {
        // 对于HLS，尝试从当前级别获取信息
        const currentLevel = player.currentLevel >= 0 ? player.currentLevel : player.autoLevelEnabled ? player.autoLevelLast : 0;
        if (player.levels[currentLevel]) {
          const levelData = player.levels[currentLevel];
          
          if (levelData.width && levelData.height) {
            streamInfo.resolution = `${levelData.width}x${levelData.height}`;
          }
          
          if (levelData.bitrate) {
            streamInfo.bitrate = `${Math.round(levelData.bitrate / 1000)} Kbps`;
          }
          
          if (levelData.videoCodec) {
            streamInfo.codec = levelData.videoCodec;
          }
        }
      } else if (streamInfo.type === 'FLV' && player.statisticsInfo) {
        // 对于FLV，尝试从统计信息获取实时码率
        const stats = player.statisticsInfo;
        
        if (stats.currentKBps) {
          const currentBitrate = Math.round(stats.currentKBps * 8);
          streamInfo.bitrate = `${currentBitrate} Kbps`;
        }
      }
    }
    
    // 然后从视频元素获取基本信息作为补充
    updateVideoInfoFromElement();
    
    // 尝试获取编解码器信息
    tryGetCodecInfo();
  }
  
  function showLoading(show) {
    loading.style.display = show ? 'block' : 'none';
  }
  
  function showError(message) {
    showLoading(false);
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
    
    // 停止信息更新定时器
    stopInfoUpdateTimer();
  }
  
  function togglePlayPause() {
    if (videoPlayer.paused) {
      play();
    } else {
      pause();
    }
  }
  
  // 记录是否是首次播放
  let isFirstPlay = true;
  
  function play() {
    // 只在首次播放时自动进入窗口全屏模式
    if (isFirstPlay && !document.fullscreenElement) {
      const container = document.querySelector('.player-container');
      if (container.requestFullscreen) {
        container.requestFullscreen();
      } else if (container.webkitRequestFullscreen) {
        container.webkitRequestFullscreen();
      } else if (container.msRequestFullscreen) {
        container.msRequestFullscreen();
      }
      isFirstPlay = false;
    }

    videoPlayer.play().then(() => {
      isPlaying = true;
      playPauseBtn.textContent = '❚❚';
    }).catch(error => {
      console.error('播放失败:', error);
    });
  }
  
  function pause() {
    videoPlayer.pause();
    isPlaying = false;
    playPauseBtn.textContent = '▶';
  }
  
  function updateProgress() {
    if (videoPlayer.duration) {
      const percent = (videoPlayer.currentTime / videoPlayer.duration) * 100;
      progressBar.style.width = percent + '%';
      
      const currentTime = formatTime(videoPlayer.currentTime);
      const duration = formatTime(videoPlayer.duration);
      timeDisplay.textContent = `${currentTime} / ${duration}`;
    }
  }
  
  function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    seconds = Math.floor(seconds % 60);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  
  function seek(e) {
    const rect = progress.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    videoPlayer.currentTime = pos * videoPlayer.duration;
  }
  
  function adjustVolume(e) {
    const rect = volumeSlider.getBoundingClientRect();
    let volume = (e.clientX - rect.left) / rect.width;
    volume = Math.max(0, Math.min(1, volume));
    
    videoPlayer.volume = volume;
    volumeProgress.style.width = (volume * 100) + '%';
    updateVolumeIcon();
    
    // 保存音量设置
    chrome.storage.local.set({ volume: volume });
  }
  
  function updateVolumeIcon() {
    if (videoPlayer.muted || videoPlayer.volume === 0) {
      volumeBtn.textContent = '🔇';
    } else if (videoPlayer.volume < 0.5) {
      volumeBtn.textContent = '🔉';
    } else {
      volumeBtn.textContent = '🔊';
    }
  }
  
  function toggleMute() {
    videoPlayer.muted = !videoPlayer.muted;
    updateVolumeIcon();
  }

  // 更新为窗口全屏
  function toggleFullscreen() {
    const container = document.querySelector('.player-container');
    if (!document.fullscreenElement) {
      if (container.requestFullscreen) {
        container.requestFullscreen();
      } else if (container.webkitRequestFullscreen) {
        container.webkitRequestFullscreen();
      } else if (container.msRequestFullscreen) {
        container.msRequestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
      }
    }
  }

  // 显示/隐藏视频信息
  function toggleVideoInfo() {
    infoPanel.style.display = infoPanel.style.display === 'none' ? 'block' : 'none';
  }
  
  // 显示/隐藏播放列表
  function togglePlaylist(show) {
    if (show === undefined) {
      playlistContainer.classList.toggle('hidden');
    } else {
      playlistContainer.classList.toggle('hidden', !show);
    }
  }
  
  function showControls() {
    controls.classList.remove('hidden');
    clearTimeout(controlsTimeout);
    
    controlsTimeout = setTimeout(() => {
      if (isPlaying) {
        controls.classList.add('hidden');
      }
    }, 3000);
  }
  
  // 播放列表自动隐藏功能
  let hidePlaylistTimeout;
  
  // 添加鼠标离开事件监听
  playlistContainer.addEventListener('mouseleave', () => {
    // 检查搜索框是否处于聚焦状态
    if (document.activeElement !== playlistSearchInput) {
      hidePlaylistTimeout = setTimeout(() => {
        togglePlaylist(false);
      }, 300);
    }
  });
  
  // 添加鼠标进入事件监听，取消隐藏计时
  playlistContainer.addEventListener('mouseenter', () => {
    if (hidePlaylistTimeout) {
      clearTimeout(hidePlaylistTimeout);
    }
  });
  
  // 事件监听
  playPauseBtn.addEventListener('click', togglePlayPause);
  progress.addEventListener('click', seek);
  volumeBtn.addEventListener('click', toggleMute);
  volumeSlider.addEventListener('click', adjustVolume);
  fullscreenBtn.addEventListener('click', toggleFullscreen);
  backBtn.addEventListener('click', () => window.close());
  infoBtn.addEventListener('click', toggleVideoInfo);
  playlistBtn.addEventListener('click', () => togglePlaylist());
  closePlaylistBtn.addEventListener('click', () => togglePlaylist(false));
  
  // 搜索相关事件监听
  playlistSearchInput.addEventListener('input', (e) => {
    searchPlaylist(e.target.value);
  });
  clearSearchBtn.addEventListener('click', clearSearch);
  
  videoPlayer.addEventListener('timeupdate', updateProgress);
  videoPlayer.addEventListener('play', () => {
    isPlaying = true;
    playPauseBtn.textContent = '❚❚';
  });
  videoPlayer.addEventListener('pause', () => {
    isPlaying = false;
    playPauseBtn.textContent = '▶';
  });
  videoPlayer.addEventListener('volumechange', updateVolumeIcon);
  
  // 添加视频结束事件处理，自动播放下一个
  videoPlayer.addEventListener('ended', function() {
    if (isM3UPlaylist && currentPlaylistIndex < currentPlaylist.length - 1) {
      playPlaylistItem(currentPlaylistIndex + 1);
    } else {
      // 停止信息更新定时器
      stopInfoUpdateTimer();
    }
  });
  
  // 鼠标移动时显示控制栏
  document.addEventListener('mousemove', showControls);
  
  // 初始化
  initPlayer();
});
