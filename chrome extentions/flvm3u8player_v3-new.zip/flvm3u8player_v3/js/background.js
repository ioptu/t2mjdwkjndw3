// Background script for Video Stream Player extension
const setupNetworkRules = () => {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1, 2],
    addRules: [
      {
        id: 1,
        priority: 1,
        action: {
          type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
          redirect: {
            regexSubstitution: `${chrome.runtime.getURL("player.html")}#\\0`
          }
        },
        condition: {
          regexFilter: "^.*\\.flv(?:\\?|$)",
          resourceTypes: [chrome.declarativeNetRequest.ResourceType.MAIN_FRAME]
        }
      },
      
      {
        id: 2,
        priority: 2,
        action: {
          type: chrome.declarativeNetRequest.RuleActionType.REDIRECT,
          redirect: {
            regexSubstitution: `${chrome.runtime.getURL("player.html")}#\\0`
          }
        },
        condition: {
          regexFilter: "^.*\\.m3u8(?:\\?|$)",
          resourceTypes: [chrome.declarativeNetRequest.ResourceType.MAIN_FRAME]
        }
      }
    ]
  });
};

// Initialize the extension
chrome.runtime.onInstalled.addListener(() => {
  console.log("Video Stream Player extension installed");
  setupNetworkRules();
});

// Handle extension updates
chrome.runtime.onStartup.addListener(() => {
  console.log("Video Stream Player extension started");
  setupNetworkRules();
});

// 添加URL重定向检测功能
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "checkRedirect") {
    console.log('检测URL重定向:', request.url);
    
	const controller = new AbortController();
	const signal = controller.signal;

	fetch(request.url, {
	  method: 'get',
	  redirect: 'follow',
	  headers: { 'Range': 'bytes=0-1' },
	  signal: signal // 将 AbortSignal 传递给 fetch
	})
	.then(response => {
	  console.log('重定向后的URL:', response.url);
	  const contentType = response.headers.get('Content-Type');
	  console.log('Content-Type:', contentType);

	  if (contentType && contentType.startsWith('video/')) {
		console.warn('检测到视频内容，中止请求。');
		controller.abort(); // 在这里中止整个请求
		sendResponse({
		  success: true,
		  finalUrl: response.url,
		  isUnsupportedVideo: true
		});
	  } else {
		sendResponse({
		  success: true,
		  finalUrl: response.url
		});
	  }
	})
	.catch(error => {
	  // 捕获中止错误
	  if (error.name === 'AbortError') {
		console.log('Fetch 请求已中止。');
	  } else {
		console.error('重定向检测失败:', error);
	  }
	  sendResponse({
		success: false,
		error: error.message
	  });
	});

	// 如果你在其他地方需要主动中止
	// setTimeout(() => controller.abort(), 5000); // 5秒后中止请求
    
    return true; // 保持消息通道开放，等待异步响应
  }
});