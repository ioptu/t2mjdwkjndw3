/**
 * M3U 播放列表解析器
 * 用于解析 M3U 格式文件，支持标准 M3U 和扩展 M3U (M3U8) 格式
 */
class M3UParser {
  constructor() {
    this.playlist = [];
  }
  
  /**
   * 解析 M3U 文件内容
   * @param {string} content - M3U 文件内容
   * @returns {Array} 解析后的播放列表项目数组
   */
  parse(content) {
    // 重置播放列表
    this.playlist = [];
    
    // 分割内容为行
    const lines = content.split(/\r?\n/);
    
    // 检查是否是有效的 M3U 文件
    if (lines.length > 0 && !lines[0].trim().startsWith('#EXTM3U')) {
      console.warn('警告: 文件可能不是标准的 M3U 格式');
    }
    
    let currentItem = null;
    
    // 逐行解析
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      // 跳过空行
      if (!line) continue;
      
      // 跳过 M3U 头部标记
      if (line.startsWith('#EXTM3U')) continue;
      
      // 解析 EXTINF 行
      if (line.startsWith('#EXTINF:')) {
        // 创建新项目
        currentItem = {
          duration: -1,
          title: '',
          tvgName: '',
          groupTitle: '',
          tvgLogo: '',
          url: ''
        };
        
        // 提取 tvg-name 属性
        const tvgNameMatch = line.match(/tvg-name="([^"]+)"/);
        if (tvgNameMatch) {
          currentItem.tvgName = tvgNameMatch[1].trim();
        }
        
        // 提取 group-title 属性
        const groupTitleMatch = line.match(/group-title="([^"]+)"/);
        if (groupTitleMatch) {
          currentItem.groupTitle = groupTitleMatch[1].trim();
        }
        
        // 提取 tvg-logo 属性
        const tvgLogoMatch = line.match(/tvg-logo="([^"]+)"/);
        if (tvgLogoMatch) {
          currentItem.tvgLogo = tvgLogoMatch[1].trim();
        }
        
        // 提取时长
        const durationMatch = line.match(/#EXTINF:(-?\d+(\.\d+)?)/);
        if (durationMatch) {
          currentItem.duration = parseFloat(durationMatch[1]);
        }
        
        // 提取频道名 - 使用最后一个逗号后的内容
        const lastCommaIndex = line.lastIndexOf(',');
        if (lastCommaIndex !== -1) {
          // 提取最后一个逗号后的所有内容作为频道名
          currentItem.title = line.substring(lastCommaIndex + 1).trim();
        } else {
          // 如果没有逗号，使用默认命名
          currentItem.title = `项目 ${this.playlist.length + 1}`;
        }
      } 
      // 处理 URL 行
      else if (!line.startsWith('#') && line) {
        // 如果没有前面的 EXTINF，创建一个默认项
        if (!currentItem) {
          currentItem = {
            duration: -1,
            title: `项目 ${this.playlist.length + 1}`,
            tvgName: '',
            groupTitle: '',
            tvgLogo: '',
            url: ''
          };
        }
        
        // 优先使用 tvg-name 作为显示标题
        // 如果没有tvg-name，则使用EXTINF行中逗号后的文本作为频道名
        if (currentItem.tvgName) {
          currentItem.title = currentItem.tvgName;
        } else if (currentItem.title) {
          // 已经在前面的解析中提取了逗号后的文本，无需再处理
          // 保留currentItem.title作为频道名
        }
        
        currentItem.url = line;
        this.playlist.push(currentItem);
        currentItem = null;
      }
    }
    
    return this.playlist;
  }
  
  /**
   * 从 URL 加载并解析 M3U 文件
   * @param {string} url - M3U 文件的 URL
   * @returns {Promise<Array>} 解析后的播放列表项目数组
   */
  async parseFromUrl(url) {
    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const content = await response.text();
      return this.parse(content);
    } catch (error) {
      console.error('解析 M3U 文件失败:', error);
      throw error;
    }
  }
  
  /**
   * 解析相对路径的 URL
   * @param {string} baseUrl - 基础 URL
   * @param {string} relativeUrl - 相对路径 URL
   * @returns {string} 完整的 URL
   */
  static resolveUrl(baseUrl, relativeUrl) {
    // 如果是绝对 URL，直接返回
    if (/^(https?:)?\/\//i.test(relativeUrl)) {
      return relativeUrl;
    }
    
    try {
      return new URL(relativeUrl, baseUrl).href;
    } catch (e) {
      console.error('URL 解析错误:', e);
      return relativeUrl;
    }
  }
}
