// 监听来自后台的消息
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {

});