document.addEventListener('DOMContentLoaded', function() {
  // 获取DOM元素
  const videoUrlInput = document.getElementById('videoUrl');
  const playBtn = document.getElementById('playBtn');
  const settingsBtn = document.getElementById('settingsBtn');
  
  // 播放按钮点击事件
  playBtn.addEventListener('click', function() {
    const url = videoUrlInput.value.trim();
    if (url) {
      playVideo(url);
    } else {
      alert('请输入有效的视频链接');
    }
  });
  
  // 播放视频
  function playVideo(url) {
    // 创建播放页面
    chrome.tabs.create({
      url: chrome.runtime.getURL('player.html') + '?url=' + encodeURIComponent(url)
    });
  }
  
  // 设置按钮点击事件
  settingsBtn.addEventListener('click', function() {
    // 打开设置页面（未实现）
    alert('设置功能将在后续版本中提供');
  });
});