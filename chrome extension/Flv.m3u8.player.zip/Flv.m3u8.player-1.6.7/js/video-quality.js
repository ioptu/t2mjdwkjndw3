(function() {
  document.addEventListener('DOMContentLoaded', async function() {
    await i18n.ready; // 确保 tooltip / 通知文案使用正确语言

    let isQualityEnhanced = false;
    let isInitialized = false;

    function createQualityControl() {
      if (document.getElementById('qualityControl')) return;
      
      const controls = document.getElementById('controls');
      const volumeContainer = document.querySelector('.volume-container');
      if (!controls || !volumeContainer) return;

      const qualityContainer = document.createElement('div');
      qualityContainer.id = 'qualityControl';
      qualityContainer.className = 'quality-container';
      qualityContainer.style.cssText = `
        display: flex;
        align-items: center;
        margin-left: 10px;
        cursor: pointer;
      `;

      const toggleBtn = document.createElement('button');
      toggleBtn.id = 'qualityToggleBtn';
      toggleBtn.className = 'quality-toggle-btn';
      toggleBtn.setAttribute("data-tooltip", i18n.t('vq_toggle_tooltip'));

      const qualityDot = document.createElement('span');
      qualityDot.className = 'quality-dot-indicator';
      
      // 恢复原始按钮样式
      toggleBtn.style.cssText = `
        background: none;
        border: none;
        cursor: pointer;
        padding: 6px;
        opacity: 0.85;
        transition: all 0.2s;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
      `;

      toggleBtn.appendChild(qualityDot);
      qualityContainer.appendChild(toggleBtn);
      
      volumeContainer.parentNode.insertBefore(qualityContainer, volumeContainer.nextSibling);

      return { button: toggleBtn, dot: qualityDot };
    }

    function createQualityStyles() {
      if (document.getElementById('quality-enhancement-styles')) return;

      const style = document.createElement('style');
      style.id = 'quality-enhancement-styles';
      style.textContent = `
        /* 极简画质增强 - 最低 GPU 占用 */
        .quality-enhanced #videoPlayer {
          filter: 
            contrast(1.06) 
            brightness(1.02) 
            saturate(1.04) !important;
          -webkit-filter: 
            contrast(1.06) 
            brightness(1.02) 
            saturate(1.04) !important;
          
          image-rendering: -webkit-optimize-contrast !important;
          /*image-rendering: crisp-edges !important;*/  /*这里是锐化*/
          transform: translateZ(0) !important;
        }

        /* 质量控制点样式 */
        .quality-dot-indicator {
          display: block !important;
          width: 12px !important;
          height: 12px !important;
          border-radius: 50% !important;
          transition: all 0.3s ease !important;
        }

        /* 开启状态 - 绿色 */
        .quality-enhanced .quality-dot-indicator {
          background: #4CAF50 !important;
          box-shadow: 
            0 0 0 2px rgba(76, 175, 80, 0.3),
            0 0 6px rgba(76, 175, 80, 0.8) !important;
          animation: qualityPulse 2s infinite !important;
        }

        /* 关闭状态 - 灰色 */
        body:not(.quality-enhanced) .quality-dot-indicator {
          background: #9CA3AF !important;
          box-shadow: 
            0 0 0 2px rgba(156, 163, 175, 0.3),
            0 0 4px rgba(156, 163, 175, 0.4) !important;
        }

        @keyframes qualityPulse {
          0%   { box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.3), 0 0 6px rgba(76, 175, 80, 0.8); }
          50%  { box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.4), 0 0 10px rgba(76, 175, 80, 1); }
          100% { box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.3), 0 0 6px rgba(76, 175, 80, 0.8); }
        }

        /* 按钮悬停效果（保持原始） */
        .quality-toggle-btn:hover .quality-dot-indicator {
          transform: scale(1.1);
        }
        .quality-toggle-btn:active .quality-dot-indicator {
          transform: scale(0.9);
        }

        /* 通知样式 */
        .quality-notification {
          position: fixed !important;
          top: 60px !important;
          left: 50% !important;
          transform: translateX(-50%) !important;
          background: rgba(40, 167, 69, 0.9) !important;
          color: white !important;
          padding: 8px 16px !important;
          border-radius: 4px !important;
          font-size: 13px !important;
          z-index: 9999 !important;
          animation: fadeInOut 2s ease-in-out forwards !important;
          pointer-events: none !important;
        }
        .quality-notification.closed {
          background: rgba(0, 100, 200, 0.9) !important;
        }
        @keyframes fadeInOut {
          0% { opacity: 0; transform: translate(-50%, -10px); }
          10% { opacity: 1; transform: translate(-50%, 0); }
          90% { opacity: 1; transform: translate(-50%, 0); }
          100% { opacity: 0; transform: translate(-50%, -10px); }
        }
      `;
      document.head.appendChild(style);
    }

    function applyQualityEnhancement(showNotification = true) {
      console.log(i18n.t('vq_console_on'));
      document.body.classList.add('quality-enhanced');
      if (showNotification) {
        showQualityNotification(i18n.t('vq_notify_on'), false);
      }
    }

    function removeQualityEnhancement(showNotification = true) {
      console.log(i18n.t('vq_console_off'));
      document.body.classList.remove('quality-enhanced');
      if (showNotification) {
        showQualityNotification(i18n.t('vq_notify_off'), true);
      }
    }

    function showQualityNotification(message, isClosed) {
      const oldNotification = document.querySelector('.quality-notification');
      if (oldNotification) oldNotification.remove();

      const notification = document.createElement('div');
      notification.className = `quality-notification ${isClosed ? 'closed' : ''}`;
      notification.textContent = message;
      document.body.appendChild(notification);

      setTimeout(() => {
        if (notification.parentNode) notification.parentNode.removeChild(notification);
      }, 2000);
    }

    function initQualityEnhancement() {
      if (isInitialized) return;
      isInitialized = true;

      createQualityStyles();
      const controls = createQualityControl();
      if (!controls) return;

      try {
        const saved = localStorage.getItem('videoQualityEnhanced');
        if (saved !== null) isQualityEnhanced = saved === 'true';
      } catch (e) {
        console.warn(i18n.t('vq_pref_load_fail_console'), e);
      }

      controls.button.addEventListener('click', function() {
        isQualityEnhanced = !isQualityEnhanced;
        if (isQualityEnhanced) {
          applyQualityEnhancement();
        } else {
          removeQualityEnhancement();
        }
        try {
          localStorage.setItem('videoQualityEnhanced', isQualityEnhanced);
        } catch (e) {
          console.warn(i18n.t('vq_pref_save_fail_console'), e);
        }
      });

      if (isQualityEnhanced) {
        applyQualityEnhancement(false);
      } else {
        removeQualityEnhancement(false);
      }

      console.log(i18n.t('vq_console_ready'));
    }

    setTimeout(initQualityEnhancement, 800);
  });
})();
