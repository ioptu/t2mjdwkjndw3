'use strict';
/**
 * js/soda-asr.js
 *
 * 基于浏览器原生 SpeechRecognition（SODA, processLocally:true）的
 * 离线实时语音识别模块，完整替代原 Whisper/transformers.js 链路
 * （whisper-iframe.js / whisper-audio-worker.js / whisper-worker.js /
 *   whisper-offscreen.js 均已删除，不再需要）。
 *
 * 音频来源：直接从 player.js 持有的 <video> 元素通过
 * AudioContext.createMediaElementSource + createMediaStreamDestination
 * 抽取一路 MediaStreamTrack 喂给 recognition.start(track)。
 * 因为不是从麦克风 getUserMedia 拿到的 track，不会触发麦克风权限弹窗；
 * 同时把该路音频接回 audioContext.destination，保证用户仍能听到声音。
 *
 * 已知平台限制（供后续排障参考）：
 *   · 不同浏览器/版本支持的语言集合差异很大（Chrome 官方支持较全，
 *     Edge 早期版本仅 en-US/de-DE/it-IT/pt-PT/es-ES/ko-KR 六种且需
 *     Canary/Dev 频道 + flag开启实验项），必须用 available() 实测，不能硬编码。
 *   · available() 显示 available 不代表 start() 一定成功
 *     （偶发 language-not-supported），这是浏览器该实验性 API 自身的
 *     不稳定行为。
 *   · install() 必须在用户点击的同步手势链路内直接调用；跨消息传递
 *     （如经 background/offscreen 中转）后调用会报
 *     "Requires handling a user gesture"。本模块的 installLang() 因此
 *     被设计为可以直接从 DOM click handler 里同步发起调用。
 *
 * 用法：
 *   const asr = new SodaAsr({ videoEl, onInterim, onFinal, onStatus, onError });
 *   await asr.start('zh-CN');
 *   asr.stop();
 *
 *   SodaAsr.LANGS                     常用语言候选表（label 已根据当前界面语言本地化）
 *   SodaAsr.checkAvailability(lang)   → 'available'|'downloadable'|'downloading'|'unavailable'|'unsupported'
 *   SodaAsr.installLang(lang)         → Promise<boolean>
 *
 * 多语言说明：本文件里所有面向用户展示的文案（语言下拉标签、onStatus/onError
 * 回调传出的提示文本）都通过 js/i18n.js 的 i18n.t() 取值，实际显示中文还是
 * 英文由浏览器语言自动决定，无需在本文件里做任何判断。
 */

const RecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;

// 常用语言候选表：code 保持不变（是实际识别用的语言代码），label 通过 i18n key
// 延迟解析，实际是否支持由 checkAvailability() 实测决定，这里只是提供一个便于选择的候选清单。
const LANG_DEFS = [
    { code: 'zh-CN', key: 'soda_lang_zh' },
    { code: 'en-US', key: 'soda_lang_en' },
    { code: 'ja-JP', key: 'soda_lang_ja' },
    { code: 'ko-KR', key: 'soda_lang_ko' },
    { code: 'de-DE', key: 'soda_lang_de' },
    { code: 'fr-FR', key: 'soda_lang_fr' },
    { code: 'ru-RU', key: 'soda_lang_ru' },
    { code: 'es-ES', key: 'soda_lang_es' },
    { code: 'it-IT', key: 'soda_lang_it' },
    { code: 'pt-PT', key: 'soda_lang_pt' },
];

// 兼容旧用法：SodaAsr.LANGS 是一个 { code, label } 数组。label 在 i18n.ready
// resolve 之后才是准确的翻译文本；在那之前（极短暂窗口）会先用 code 兜底，
// 随后 refreshLangLabels() 会把已经渲染出来的下拉框标签刷新成正确文案。
const LANGS = LANG_DEFS.map((l) => ({ code: l.code, label: l.code }));

function refreshLangLabels() {
    LANG_DEFS.forEach((def, idx) => {
        LANGS[idx].label = i18n.t(def.key);
    });
}
if (window.i18n) {
    i18n.ready.then(refreshLangLabels);
} else {
    // i18n.js 理论上应该总是先于本文件加载；万一顺序被改动，做个兜底轮询。
    const timer = setInterval(() => {
        if (window.i18n) {
            clearInterval(timer);
            i18n.ready.then(refreshLangLabels);
        }
    }, 50);
}

async function checkAvailability(langCode) {
    if (!RecognitionAPI || typeof RecognitionAPI.available !== 'function') return 'unsupported';
    try {
        const st = await RecognitionAPI.available({ langs: [langCode], processLocally: true });
        return st || 'unavailable';
    } catch (e) {
        return 'unsupported';
    }
}

// 注意：调用方必须保证这是从用户点击事件回调里直接、同步触发的
// （中间不能先 await 别的异步操作再调用它），否则浏览器会拒绝安装。
async function installLang(langCode) {
    if (!RecognitionAPI || typeof RecognitionAPI.install !== 'function') return false;
    try {
        return !!(await RecognitionAPI.install({ langs: [langCode], processLocally: true }));
    } catch (e) {
        console.warn(i18n.t('soda_install_fail_console'), e && e.message);
        return false;
    }
}

class SodaAsr {
    constructor({ videoEl, onInterim, onFinal, onStatus, onError, getAudioTrack  }) {
        this.videoEl   = videoEl;
        this.onInterim = onInterim || function () {};
        this.onFinal   = onFinal   || function () {};
        this.onStatus  = onStatus  || function () {};
        this.onError   = onError   || function () {};
        // 可选：外部（player.js）提供的共享音频图获取函数，返回
        // {audioContext, track}。提供时优先复用，不再自己
        // createMediaElementSource——见 _acquireTrack() 里的说明。
        this._getAudioTrack = typeof getAudioTrack === 'function' ? getAudioTrack : null;

        this.recognition  = null;
        this.audioCtx     = null;
        this.sourceNode   = null;
        this.destNode     = null;
        this.track        = null;
        this._graphReady  = false; // 音频抓取图（Context+SourceNode）是否已建立
        this._pendingRescue = null; // 未定稿骤降抢救机制的挂起状态，见 _createRecognition()
        this.lang         = 'zh-CN';
        this.enabled      = false;
        this._userStopped = true;
    }

    get supported() {
        return !!RecognitionAPI;
    }

    // ── 从 <video> 元素抽取音频 track ──────────────────────────────
    //
    // 重要：createMediaElementSource() 对同一个 <video> 元素在其整个
    // DOM 生命周期内只能成功调用一次——这个绑定是浏览器内部永久性的，
    // 即使后续把 AudioContext close() 掉也无法解除，再次调用会直接
    // 抛出 InvalidStateError。因此这个音频图必须只建立一次，
    // 开关字幕只应该控制 SpeechRecognition 的启停，绝不能在 stop()
    // 里销毁 Context / SourceNode，否则：
    //   1) close() 会切断 video 的音频输出链路 → 停止字幕后没声音；
    //   2) 下次开启再调 createMediaElementSource 会直接报错；
    //   3) 处于半损坏状态的音频图还可能连带卡住视频解码时钟。
    //
    // 同样因为这个"整个生命周期只能成功一次"的限制，这个模块不能自己
    // 想调用就调用——页面上如果还有别的功能（比如响度均衡）也需要抽取
    // 同一个 <video> 的音频，两边各自调用必然有一个失败。构造函数如果
    // 传入了 getAudioTrack，就优先复用外部已经建立/将会建立的共享音频图；
    // 没有传入时才退回到自己独立建图（保持向后兼容，单独使用本模块时
    // 仍然可以工作）。
    _acquireTrack() {
        if (this._graphReady) return this.track;

        if (this._getAudioTrack) {
            const result = this._getAudioTrack();
            if (!result || !result.track) {
                throw new Error('无法获取共享音频轨道（音频图未就绪，可能是响度均衡那边初始化失败）');
            }
            this.audioCtx    = result.audioContext;
            this.track       = result.track;
            this._graphReady = true;
            return this.track;
        }

        // 独立模式：没有提供 getAudioTrack 时的原始行为
        this.audioCtx   = new (window.AudioContext || window.webkitAudioContext)();
        this.sourceNode = this.audioCtx.createMediaElementSource(this.videoEl);
        this.destNode   = this.audioCtx.createMediaStreamDestination();
        this.sourceNode.connect(this.destNode);              // 一路送给识别
        this.sourceNode.connect(this.audioCtx.destination);  // 一路接回正常播放，保持有声音
        this.track = this.destNode.stream.getAudioTracks()[0];
        this._graphReady = true;
        return this.track;
    }

    // ── 未定稿内容"骤降丢失"抢救机制 ────────────────────────────
    // 超长无停顿语音场景下，SODA 有时会在同一个 resultIndex 内部让未定稿显示
    // 突然从一长串缩水成个位数字符，如果不做任何处理，缩水前那一大段内容既
    // 没有被 onFinal 定稿过，也马上被后面更新的未定稿覆盖掉，就永久丢失了。
    //
    // 骤降不代表内容真的丢了——
    // 多数情况下这个 resultIndex 会自己重新长回来、最终正常定稿，且定稿内容基本
    // 等同于骤降前的那一长串（引擎内部其实一直留着，只是未定稿显示这层临时
    // 抽风了）。如果一检测到骤降就立刻强制归档，等它之后又正常定稿，就会
    // 变成同一段内容重复显示两次。所以不能"立刻抢救"，要"延迟确认"：
    //   · 长度追回到骤降前水平 → 引擎自己找回来了，取消抢救；
    //   · 还没追回、也还没定稿 → 继续挂起等；
    //   · 还没追回、但已经定稿了 → 不用等挂起时间到期，立刻确认丢失并抢救；
    //   · 挂起满 RESCUE_GRACE_MS 仍未追回 → 确认真的丢了，强制抢救。
    // "抢救"具体做法是把骤降前缓存的内容当成一条迟来的定稿，调用 this.onFinal()，
    // 走跟正常定稿完全一样的归档路径（进历史区、触发翻译）。
    static get RESCUE_MIN_PREV_LENGTH() { return 100; } // 缓存内容至少要有这么长，才值得被"突然变短"这个判断盯上
    static get RESCUE_MAX_NEW_LENGTH()  { return 50; }  // 新内容如果只剩这么短，判定为疑似骤降
    static get RESCUE_GRACE_MS()        { return 3000; } // 骤降后最多等这么久，仍未追回长度就确认放弃、执行抢救

    _cancelPendingRescue() {
        if (this._pendingRescue) {
            clearTimeout(this._pendingRescue.timer);
            this._pendingRescue = null;
        }
    }
    // 立即执行抢救：把骤降前缓存的内容强制当作一条定稿上报。timer 到期和
    // "已经定稿但长度没追上"这两个触发点都会调用这里。
    _doRescue(rescue) {
        if (rescue && rescue.droppedText) {
            console.warn(`[SodaAsr] resultIndex=${rescue.index} 确认被丢弃内容没有找回，强制归档抢救内容: "${rescue.droppedText}"`);
            this.onFinal(rescue.droppedText);
        }
    }

    _createRecognition() {
        const r = new RecognitionAPI();
        r.lang           = this.lang;
        r.continuous     = true;
        r.interimResults = true;
        r.processLocally = true;
		if ('unspokenPunctuation' in r) {
		  r.unspokenPunctuation = true;
		}

        // 抢救机制的状态，挂在 this 上（而不是纯闭包局部变量）是为了让 stop() 在
        // 用户主动停止字幕时能拿到并清理掉可能还挂起中的抢救定时器，避免停止之后
        // 定时器还在后台跑，过几秒突然又冒出一条迟到的字幕。
        this._pendingRescue        = null; // { index, droppedText, droppedLength, timer }
        let currentIndexCachedText = '';   // 当前 resultIndex 目前为止见过的最长未定稿内容
        let currentIndexTrackedAt  = -1;   // 上面这份缓存是哪个 resultIndex 的，索引变了要重新开始缓存

        r.onresult = (e) => {
            const currentIndex       = e.resultIndex;
            const currentIndexResult = e.results[currentIndex];
            const isCurrentFinal     = !!(currentIndexResult && currentIndexResult.isFinal);
            const currentIndexText   = ((currentIndexResult && currentIndexResult[0] && currentIndexResult[0].transcript) || '').trim();

            // 正确的"是否还需要继续挂起等"判断标准是"内容长度有没有追回到骤降前的
            // 水平"，而不是"有没有任何后续动静"——否则如果被丢弃后引擎压根没找回
            // 原内容，只是从骤降那一刻开始识别一段全新的、无关的内容然后就定稿了，
            // 会被误判成"不用抢救"，丢弃的那段就再也回不来了。
            if (this._pendingRescue && this._pendingRescue.index === currentIndex) {
                if (currentIndexText.length >= Math.floor(this._pendingRescue.droppedLength * 0.95)) {
                    this._cancelPendingRescue();
                } else if (isCurrentFinal) {
                    this._doRescue(this._pendingRescue);
                    this._cancelPendingRescue();
                }
                // 否则：还没定稿、长度也还没追上——继续挂起，不做任何处理。
            }

            // 索引变了（正常翻到下一句），缓存基准要重新开始，不能拿上一句的
            // 长度来跟这一句比较。
            if (currentIndex !== currentIndexTrackedAt) {
                currentIndexCachedText = '';
                currentIndexTrackedAt  = currentIndex;
            }

            // 骤降检测：同一个索引内，还没定稿，但内容突然从一长串缩水成个位数——
            // 正常的未定稿更新只会越来越长，这种断崖式缩短不是正常现象。
            if (
                !isCurrentFinal &&
                currentIndexCachedText.length >= SodaAsr.RESCUE_MIN_PREV_LENGTH &&
                currentIndexText.length <= SodaAsr.RESCUE_MAX_NEW_LENGTH
            ) {
                const textAtShrinkTime  = currentIndexCachedText;
                const indexAtShrinkTime = currentIndex;
                console.warn(`[SodaAsr] 检测到 resultIndex=${indexAtShrinkTime} 内容突然从"${textAtShrinkTime}"（${textAtShrinkTime.length}字）缩短为"${currentIndexText}"（${currentIndexText.length}字），挂起等待最多 ${SodaAsr.RESCUE_GRACE_MS}ms`);
                this._pendingRescue = {
                    index: indexAtShrinkTime,
                    droppedText: textAtShrinkTime,
                    droppedLength: textAtShrinkTime.length,
                    timer: setTimeout(() => {
                        if (this._pendingRescue && this._pendingRescue.index === indexAtShrinkTime) {
                            this._doRescue(this._pendingRescue);
                            this._pendingRescue = null;
                        }
                    }, SodaAsr.RESCUE_GRACE_MS),
                };
            }

            // 更新缓存：只要还没定稿，就把这次看到的内容当作"目前为止最长版本"存起来
            // （正常情况下内容只会越来越长，直接覆盖存最新的就等于存最长的）。
            currentIndexCachedText = isCurrentFinal ? '' : currentIndexText;

            for (let i = e.resultIndex; i < e.results.length; i++) {
                const res  = e.results[i];
                const text = ((res[0] && res[0].transcript) || '').trim();
                if (!text) continue;
                if (res.isFinal) this.onFinal(text);
                else              this.onInterim(text);
            }
        };
        r.onerror = (e) => {
            // no-speech 是正常的静音间隙，不当错误上报，交给 onend 处理重启
            if (e.error === 'no-speech' || e.error === 'aborted') return;
            this.onError(e.error);
        };
        r.onend = () => {
            // 识别会话结束（不管是致命错误还是自动重启前的中断），任何还挂起中的
            // 抢救都不会再有新的 onresult 来更新它了，与其让它悬空等到超时，
            // 不如现在就确认执行——避免这次遗留的内容彻底消失。
            if (this._pendingRescue) {
                this._doRescue(this._pendingRescue);
                this._cancelPendingRescue();
            }
            // continuous 模式下浏览器仍可能自行结束会话（已知的不稳定行为），
            // 只要用户没有主动停止字幕，就自动重启，维持"持续识别"体验。
            if (this.enabled && !this._userStopped) {
                setTimeout(() => {
                    if (this.enabled && !this._userStopped) this._restart();
                }, 250);
            } else {
                this.onStatus('idle');
            }
        };
        return r;
    }

    _restart() {
        try {
            this.recognition = this._createRecognition();
            this.recognition.start(this.track || this._acquireTrack());
        } catch (e) {
            this.onError(i18n.t('soda_err_restart_failed', { MSG: e.message }));
        }
    }

    async start(langCode) {
        if (!this.supported) {
            this.onError(i18n.t('soda_err_unsupported_browser'));
            return;
        }
        if (this.enabled) return;
        this.lang          = langCode || this.lang;
        this._userStopped  = false;
        this.onStatus('loading', i18n.t('soda_status_checking_model'));

        const avail = await checkAvailability(this.lang);
        if (avail === 'unavailable' || avail === 'unsupported') {
            this.onError(avail === 'unsupported'
                ? i18n.t('soda_err_lang_unsupported')
                : i18n.t('soda_err_lang_unavailable'));
            return;
        }
        if (avail === 'downloadable' || avail === 'downloading') {
            this.onError(i18n.t('soda_err_model_not_downloaded'));
            return;
        }

        try {
            const track = this._acquireTrack();
            if (this.audioCtx && this.audioCtx.state === 'suspended') {
                this.audioCtx.resume().catch(() => {});
            }
            this.enabled      = true;
            this.recognition  = this._createRecognition();
            this.recognition.start(track);
            this.onStatus('running', i18n.t('soda_status_running', { LANG: this.lang }));
        } catch (e) {
            this.enabled = false;
            this.onError(i18n.t('soda_err_start_failed', { MSG: e.message }));
        }
    }

    stop() {
        this._userStopped = true;
        this.enabled       = false;
        this._cancelPendingRescue();
        if (this.recognition) {
            try { this.recognition.stop(); } catch (_) {}
            this.recognition = null;
        }
        // 注意：这里绝不能关闭 audioCtx（共享模式下这个 audioCtx 属于外部，
        // 独立模式下则是 <video> 音频能正常播放的唯一路径——见 _acquireTrack
        // 注释），关掉就再也连不回去了。只停止识别本身。
        this.onStatus('idle', i18n.t('soda_status_stopped'));
    }
}

SodaAsr.LANGS              = LANGS;
SodaAsr.checkAvailability  = checkAvailability;
SodaAsr.installLang        = installLang;

window.SodaAsr = SodaAsr;