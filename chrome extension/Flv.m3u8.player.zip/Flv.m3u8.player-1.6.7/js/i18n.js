'use strict';
/**
 * js/i18n.js
 *
 * 统一的中/英双语支持模块，供 popup / player / settings 等所有扩展页面共用。
 *
 * 语言判定规则（按需求约定，不依赖 chrome.i18n 内置的 _locales 自动匹配机制，
 * 因为那套机制只会精确匹配已提供的 locale 目录名（如 "zh_CN"），像 zh_TW/zh_HK
 * 这类变体在只提供 zh_CN 时会被判为"不匹配"而回退到 default_locale，无法保证
 * "只要是中文环境就用中文"这条规则一定成立。这里改为自己读取浏览器语言并按前缀
 * 判断，保证结果：
 *   浏览器语言（chrome.i18n.getUILanguage() / navigator.language）以 "zh" 开头 → 中文
 *   其余任何语言 → 英文
 * 判定结果只用于决定加载 _locales/zh_CN/messages.json 还是 _locales/en/messages.json，
 * 文件内容仍是标准 messages.json 格式。
 *
 * 占位符约定：文案里一律使用 {{XXX}} 形式的占位符，不要使用 $XXX$。
 * 原因：chrome.i18n 的消息系统会把消息文本里任何 $WORD$ 形式的片段当成占位符
 * 自动处理（哪怕这个占位符根本没有在 messages.json 的 "placeholders" 字段里声明，
 * 也没有在调用时传 substitutions），未声明的会被直接替换成空字符串，导致文案被
 * 静默吞掉一截。本模块不经过 chrome.i18n.getMessage 的占位符替换逻辑（直接 fetch
 * messages.json 拿原始文案），替换统一由下面的 t() 用字符串 split/join 手动完成，
 * 因此可以放心使用 {{XXX}}。
 *
 * 加载时机：脚本一执行就立即开始 fetch 对应语言包（不等 DOMContentLoaded，因为
 * fetch 本身不依赖 DOM），并把这个过程缓存成 i18n.ready（Promise）。多个页面/
 * 多处代码都可以放心 `await i18n.ready` 或 `await i18n.init()`（两者等价，
 * 重复调用不会重复发起请求）。
 *
 * 用法：
 *   HTML:
 *     <span data-i18n="popup_play_btn"></span>
 *     <input data-i18n-placeholder="popup_url_placeholder">
 *     <button data-i18n-title="popup_settings_btn"></button>
 *     <div data-i18n-html="popup_help_tips_content"></div>   // 文案含 HTML/转义字符时用
 *
 *   JS：
 *     await i18n.ready;   // 或 await i18n.init();
 *     el.textContent = i18n.t('soda_status_running', { LANG: 'zh-CN' });
 *
 * 注意：本文件必须在其它任何会用到 i18n.t() / data-i18n* 的脚本之前加载
 * （<script src="js/i18n.js"> 放在最前面），并且用到 i18n.t() 的代码需要
 * 自己 `await i18n.ready` 之后再执行，以避免语言包还没加载完就取值。
 */
(function (root) {
    let currentLocale = 'en';
    let messages = {};

    function detectLocale() {
        let lang = '';
        try {
            if (root.chrome && chrome.i18n && typeof chrome.i18n.getUILanguage === 'function') {
                lang = chrome.i18n.getUILanguage() || '';
            }
        } catch (e) { /* ignore */ }
        if (!lang) lang = (navigator.language || navigator.userLanguage || '');
        return /^zh/i.test(lang) ? 'zh_CN' : 'en';
    }

    async function loadMessages(locale) {
        const url = chrome.runtime.getURL(`_locales/${locale}/messages.json`);
        const res = await fetch(url);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
    }

    function t(key, subs) {
        const entry = messages[key];
        let text = (entry && typeof entry.message === 'string') ? entry.message : key;
        if (subs) {
            for (const k in subs) {
                if (Object.prototype.hasOwnProperty.call(subs, k)) {
                    text = text.split(`{{${k}}}`).join(String(subs[k]));
                }
            }
        }
        return text;
    }

    function applyDom(scopeEl) {
        const scope = scopeEl || document;
        scope.querySelectorAll('[data-i18n]').forEach((el) => {
            el.textContent = t(el.getAttribute('data-i18n'));
        });
        scope.querySelectorAll('[data-i18n-html]').forEach((el) => {
            el.innerHTML = t(el.getAttribute('data-i18n-html'));
        });
        scope.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
            el.setAttribute('placeholder', t(el.getAttribute('data-i18n-placeholder')));
        });
        scope.querySelectorAll('[data-i18n-title]').forEach((el) => {
            el.setAttribute('title', t(el.getAttribute('data-i18n-title')));
        });
        scope.querySelectorAll('[data-i18n-aria-label]').forEach((el) => {
            el.setAttribute('aria-label', t(el.getAttribute('data-i18n-aria-label')));
        });
        scope.querySelectorAll('[data-i18n-tooltip]').forEach((el) => {
            el.setAttribute('data-tooltip', t(el.getAttribute('data-i18n-tooltip')));
        });
    }

    async function doInit() {
        currentLocale = detectLocale();
        try {
            messages = await loadMessages(currentLocale);
        } catch (e) {
            console.warn('[i18n] 加载语言包失败，回退到英文:', e);
            currentLocale = 'en';
            try { messages = await loadMessages('en'); } catch (e2) { messages = {}; }
        }
        // DOM 可能还没解析完（脚本一加载就开始 fetch），此时套用一次；
        // 各页面自己的 DOMContentLoaded 里如果又调用了 i18n.init()/applyDom()，
        // 会拿到同一个已 resolve 的 Promise，再套用一次也无副作用。
        const apply = () => applyDom();
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', apply, { once: true });
        } else {
            apply();
        }
        return currentLocale;
    }

    let initPromise = null;
    function init() {
        if (!initPromise) initPromise = doInit();
        return initPromise;
    }

    root.i18n = {
        init,
        t,
        applyDom,
        get ready() { return init(); },
        get locale() { return currentLocale; }
    };

    // 脚本一加载就立即开始，不必等待任何页面显式调用。
    init();
})(window);
