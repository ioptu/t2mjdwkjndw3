'use strict';
/**
 * js/soda-panel.js
 *
 * 实时字幕控制面板的 UI 交互逻辑：
 *   · 语言选择下拉框（候选表来自 SodaAsr.LANGS）
 *   · 所选语言的离线模型状态检测（可用 / 需下载 / 下载中 / 不可用）+ 下载按钮
 *   · "开启字幕 / 停止字幕"切换按钮
 *
 * 依赖 js/i18n.js 和 js/soda-asr.js 先加载（分别提供 window.i18n / window.SodaAsr）。
 * player.js 把 _startSodaAsr / _stopSodaAsr / state 挂到 window，本文件只调用它们。
 *
 * 替代原 whisper-ui.js（Whisper 模型/推理设备选择面板，已删除）。
 */
(function () {
    document.addEventListener('DOMContentLoaded', async function () {
        await i18n.ready; // 确保下面用到的所有文案都已经是正确语言

        var panel     = document.getElementById('whisper-panel');
        var toggleBtn = document.getElementById('whisper-toggle-btn');
        var langSel   = document.getElementById('soda-lang-select');
        var badge     = document.getElementById('soda-lang-status-badge');
        var dlBtn     = document.getElementById('soda-lang-download-btn');
        var statusEl  = document.getElementById('whisper-status-text');
        // 视频总结相关元素
        var summaryToggle   = document.getElementById('summary-toggle');
        var summaryIntervalRow    = document.getElementById('summary-interval-row');
        var summaryIntervalSelect = document.getElementById('summary-interval-select');
        var summaryStatusEl = document.getElementById('summary-status-text');
        var summaryResultsEl = document.getElementById('summary-results');
        var summaryCountdownEl = document.getElementById('summary-countdown');

        if (!panel || !toggleBtn || !langSel || !badge || !dlBtn) return;

        function escapeHtmlLite(s) {
            return String(s == null ? '' : s)
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
        }
        // 把 state.summary.results 渲染到面板里；由 player.js 在总结状态变化
        // （开始一轮、流式追加、完成、失败）时通过 state.summary.onUpdate 回调过来，
        // 也会在开关/间隔变化、面板重新打开时手动调用一次。
        // 倒计时展示：等下一次自动总结还有多久。state.summary.nextSummaryAt 是
        // player.js 那边维护的一个时间戳（Date.now() 毫秒），每次开启/改间隔/
        // 每轮总结开始时都会重新计算，这里只负责每秒读一次、格式化成 mm:ss 显示。
        // 用固定的 1 秒 setInterval，这个绑定只在 DOMContentLoaded 里执行一次
        // （不像 attachCommonVideoEvents 那样会随换台反复调用），不用担心叠加。
        function updateSummaryCountdown() {
            if (!summaryCountdownEl) return;
            var summary = window.state && window.state.summary;
            if (!summary || !summary.enabled || !summary.nextSummaryAt) {
                summaryCountdownEl.textContent = '';
                return;
            }
            var remainingMs = summary.nextSummaryAt - Date.now();
            if (remainingMs < 0) remainingMs = 0;
            var totalSec = Math.floor(remainingMs / 1000);
            var mm = Math.floor(totalSec / 60);
            var ss = totalSec % 60;
            var mmss = (mm < 10 ? '0' : '') + mm + ':' + (ss < 10 ? '0' : '') + ss;
            // 正在总结/翻译中时不显示倒计时（这一轮已经在跑了，倒计时其实是给
            // 下一轮排的），改成什么都不显示——避免又是"总结中"又是"下次总结"
            // 两条状态同时出现造成混乱；summary-status-text 那条会显示下载进度等信息。
            var summarizing = summary.results && summary.results.length &&
                summary.results[summary.results.length - 1].phase &&
                ['summarizing', 'translating'].indexOf(summary.results[summary.results.length - 1].phase) !== -1 &&
                summary.running;
            summaryCountdownEl.textContent = summarizing ? '' : i18n.t('player_summary_next_in', { TIME: mmss });
        }
        setInterval(updateSummaryCountdown, 1000);

        function renderSummaryResults() {
            if (!summaryResultsEl) return;
            var summary = window.state && window.state.summary;
            var results = (summary && summary.results) || [];
            if (!results.length) {
                summaryResultsEl.innerHTML = '<div class="wp-summary-empty">' + i18n.t('player_summary_empty') + '</div>';
                return;
            }
            summaryResultsEl.innerHTML = results.map(function (r) {
                var body;
                if (r.error) {
                    body = i18n.t('player_summary_failed');
                } else if (r.phase === 'translating') {
                    body = i18n.t('player_summary_translating');
                } else if (!r.text) {
                    body = i18n.t('player_summary_summarizing');
                } else {
                    body = escapeHtmlLite(r.text).replace(/\n/g, '<br>');
                }
                return '<div class="wp-summary-entry"><div class="wp-summary-time">' + escapeHtmlLite(r.rangeLabel) + '</div><div>' + body + '</div></div>';
            }).join('');
            summaryResultsEl.scrollTop = summaryResultsEl.scrollHeight;
        }
        // 把开关/间隔选择框等 UI 状态跟 state.summary / state.whisper 对齐。
        // 字幕关闭时开关必须是 disabled 的（需求里明确"只有开启实时字幕时开关才可用"）。
        function syncSummaryUI() {
            var whisperEnabled = window.state && window.state.whisper && window.state.whisper.enabled;
            var summary = window.state && window.state.summary;
            var summaryEnabled = !!(summary && summary.enabled);
            if (summaryToggle) {
                summaryToggle.disabled = !whisperEnabled;
                summaryToggle.checked = summaryEnabled;
            }
            if (summaryIntervalRow) {
                summaryIntervalRow.style.display = summaryEnabled ? 'flex' : 'none';
            }
            if (summaryIntervalSelect && summary) {
                summaryIntervalSelect.value = String(summary.intervalMinutes || 10);
            }
            if (summaryResultsEl) {
                var hasResults = summary && summary.results && summary.results.length;
                summaryResultsEl.style.display = (summaryEnabled || hasResults) ? 'block' : 'none';
            }
            if (summaryStatusEl && !whisperEnabled) {
                summaryStatusEl.textContent = '';
            }
            renderSummaryResults();
            updateSummaryCountdown();
        }
        // 注册渲染回调，供 player.js 在总结状态变化时主动通知面板刷新
        if (window.state && window.state.summary) {
            window.state.summary.onUpdate = function () {
                renderSummaryResults();
                updateSummaryCountdown();
                // 开关/结果区的显示与隐藏也可能因为总结完成/出错而需要更新
                if (summaryResultsEl) {
                    var summary = window.state.summary;
                    var hasResults = summary && summary.results && summary.results.length;
                    summaryResultsEl.style.display = (summary.enabled || hasResults) ? 'block' : 'none';
                }
            };
        }
        if (summaryToggle) {
            summaryToggle.addEventListener('change', function () {
                if (typeof window._setVideoSummaryEnabled === 'function') {
                    window._setVideoSummaryEnabled(summaryToggle.checked);
                }
                syncSummaryUI();
            });
        }
        if (summaryIntervalSelect) {
            summaryIntervalSelect.addEventListener('change', function () {
                if (typeof window._setSummaryIntervalMinutes === 'function') {
                    window._setSummaryIntervalMinutes(summaryIntervalSelect.value);
                }
            });
        }

        var LANGS = (window.SodaAsr && window.SodaAsr.LANGS) || [];
        var currentStatus = 'unsupported';
        var checkToken = 0; // 防止并发检测时旧结果覆盖新结果

        // ── 填充语言下拉框 ─────────────────────────────────────────
        LANGS.forEach(function (l) {
            var opt = document.createElement('option');
            opt.value = l.code;
            opt.textContent = l.label;
            langSel.appendChild(opt);
        });
        // 默认优先中文（若候选表里有）
        var zh = LANGS.filter(function (l) { return l.code === 'zh-CN'; })[0];
        if (zh) langSel.value = zh.code;
        if (window.state && window.state.whisper) {
            window.state.whisper.language = langSel.value;
        }

        function setBadge(status) {
            currentStatus = status;
            badge.className = 'soda-badge ' + status;
            dlBtn.style.display = 'none';
            switch (status) {
                case 'available':
                    badge.textContent = i18n.t('soda_badge_ready');
                    break;
                case 'downloadable':
                    badge.textContent = i18n.t('soda_badge_need_download');
                    dlBtn.style.display = 'inline-block';
                    dlBtn.disabled = false;
                    dlBtn.textContent = i18n.t('soda_btn_download');
                    break;
                case 'downloading':
                    badge.textContent = i18n.t('soda_badge_downloading');
                    dlBtn.style.display = 'inline-block';
                    dlBtn.disabled = true;
                    dlBtn.textContent = i18n.t('soda_badge_downloading');
                    break;
                case 'unavailable':
                    badge.textContent = i18n.t('soda_badge_unavailable');
                    break;
                case 'unsupported':
                default:
                    badge.textContent = i18n.t('soda_badge_unsupported');
                    break;
            }
            if (window.state && window.state.whisper) {
                window.state.whisper.langStatus = status;
            }
        }

        function refreshStatus() {
            if (!window.SodaAsr) return;
            var token = ++checkToken;
            badge.className = 'soda-badge checking';
            badge.textContent = i18n.t('soda_badge_checking');
            dlBtn.style.display = 'none';
            window.SodaAsr.checkAvailability(langSel.value).then(function (st) {
                if (token !== checkToken) return; // 语言已经切换，丢弃过期结果
                setBadge(st);
            });
        }

        langSel.addEventListener('change', function () {
            if (window.state && window.state.whisper) {
                window.state.whisper.language = langSel.value;
            }
            refreshStatus();
        });

        // ── 下载按钮：必须直接在点击回调的同步链路内调用 install() ──────
        // （中间不能先 await 别的东西，否则浏览器会拒绝：
        //   "Requires handling a user gesture"）
        dlBtn.addEventListener('click', function () {
            var lang = langSel.value;
            setBadge('downloading');
            window.SodaAsr.installLang(lang).then(function (ok) {
                if (langSel.value !== lang) return; // 下载期间用户切换了语言，忽略
                refreshStatus();
                if (!ok && statusEl) {
                    statusEl.textContent = i18n.t('soda_status_download_failed');
                }
            });
        });

        // ── 点击面板外关闭 ─────────────────────────────────────────
        document.addEventListener('click', function (e) {
            var whisperBtn = document.getElementById('whisperBtn');
            if (!panel.contains(e.target) && !(whisperBtn && whisperBtn.contains(e.target))) {
                panel.classList.remove('show');
            }
        });

        // 每次打开面板时刷新一次状态（模型可能是浏览器后台下载完成的）
        var whisperBtnEl = document.getElementById('whisperBtn');
        if (whisperBtnEl) {
            whisperBtnEl.addEventListener('click', function () {
                if (panel.classList.contains('show')) {
                    refreshStatus();
                    syncSummaryUI();
                }
            });
        }

        // ── 开启 / 停止 ───────────────────────────────────────────
        toggleBtn.addEventListener('click', function () {
            var whisperBtn = document.getElementById('whisperBtn');
            var enabled = window.state && window.state.whisper && window.state.whisper.enabled;

            if (enabled) {
                if (typeof window._stopSodaAsr === 'function') window._stopSodaAsr();
                toggleBtn.textContent = i18n.t('soda_btn_start_caption');
                toggleBtn.classList.remove('active');
                if (whisperBtn) whisperBtn.classList.remove('active');
                syncSummaryUI(); // 字幕关闭后总结也会被 player.js 强制关闭，这里同步一下开关/结果区的显示
                return;
            }

            if (currentStatus !== 'available') {
                if (statusEl) statusEl.textContent = i18n.t('soda_status_need_download_first');
                return;
            }
            if (window.state && window.state.whisper) {
                window.state.whisper.language = langSel.value;
            }
            if (typeof window._startSodaAsr === 'function') window._startSodaAsr();
            toggleBtn.textContent = i18n.t('soda_btn_stop_caption');
            toggleBtn.classList.add('active');
            if (whisperBtn) whisperBtn.classList.add('active');
            syncSummaryUI(); // 字幕开启后总结开关才可用（此时刚被 player.js 重置为关闭状态）
        });

        // 初始检测一次
        refreshStatus();
        syncSummaryUI();
    });
})();