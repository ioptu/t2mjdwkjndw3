document.addEventListener("DOMContentLoaded", async function() {
    await i18n.init(); // 先根据浏览器语言加载对应文案并套用所有 data-i18n* 节点，再往下走

    const videoUrlInput = document.getElementById("videoUrl");
    const playBtn = document.getElementById("playBtn");
    const settingsBtn = document.getElementById("settingsBtn");
    const epgToggle = document.getElementById("epgToggle");  // 新增
    // 新增：播放记录相关元素
    const historyDropdownToggle = document.getElementById("historyDropdownToggle");
    const historyDropdown = document.getElementById("historyDropdown");
    const historyList = document.getElementById("historyList");
    const historyClearBtn = document.getElementById("historyClearBtn");
    const historyEnableToggle = document.getElementById("historyEnableToggle");
    // 尝试自动填充上次播放的URL
    // chrome.storage.local.get(['lastVideoUrl'], function(result) {
    //     if (result.lastVideoUrl) {
    //         videoUrlInput.value = result.lastVideoUrl;
    //     }
    // });
    // 新增：加载 EPG 开关状态
    const helpIcon = document.getElementById("helpIcon");
    const helpText = document.getElementById("helpText");
    
    if (helpIcon && helpText) {
        helpIcon.addEventListener("click", function() {
            if (helpText.style.display === "none") {
                helpText.style.display = "block";
                helpIcon.textContent = "×";  // 点一下变成 × 再点隐藏
                helpIcon.title = i18n.t("popup_help_title_hide");
            } else {
                helpText.style.display = "none";
                helpIcon.textContent = "?";
                helpIcon.title = i18n.t("popup_help_title_show");
            }
        });
    }
    function loadEpgState() {
        chrome.storage.local.get(null, function(result) {  // 获取所有配置
            const enabled = result.epgEnabled !== undefined ? result.epgEnabled : false;  // 默认 false，与 settings 默认一致
            epgToggle.checked = enabled;
        });
    }
    // 新增：保存 EPG 状态并模拟 settings 保存（即时生效）
    function saveEpgState(enabled) {
        // 先获取当前所有配置
        chrome.storage.local.get(null, function(currentConfig) {
            // 更新 epgEnabled（其他字段保持不变）
            const updatedConfig = {
                ...currentConfig,
                epgEnabled: enabled
            };
            // 保存整个更新后的 config 到 storage
            chrome.storage.local.set(updatedConfig, function() {
                if (chrome.runtime.lastError) {
                    console.error(i18n.t("popup_epg_save_fail_console"), chrome.runtime.lastError);
                    return;
                }
                // 发送与 settings.js 相同的消息，带整个 config（让 player 等页面即时更新）
                try {
                    chrome.runtime.sendMessage({
                        action: 'settingsUpdated',
                        config: updatedConfig
                    });
                } catch (error) {
                    console.warn(i18n.t("popup_settings_msg_fail_console"), error);
                }
            });
        });
    }
    // 新增：初始化加载状态
    loadEpgState();
    // 新增：开关变化时立即保存并通知
    //const epgToggle = document.getElementById("epgToggle");
    if (epgToggle) {
        epgToggle.addEventListener('change', function() {
            saveEpgState(this.checked);
        });
    }
    // ================== 新增：播放记录（Playback History）功能 ==================
    // 存储结构：chrome.storage.local
    //   playHistory:     Array<{ id, url, title, createdAt, editedAt, pinned }>
    //   historyEnabled:  boolean（是否记录播放历史，默认 false）
    // 排序规则：
    //   置顶（pinned，即标题被用户编辑过）条目按 editedAt 从新到旧排在最前面，
    //   其余未编辑条目按 createdAt 从新到旧排在后面。
    const HISTORY_STORAGE_KEY = "playHistory";
    const HISTORY_ENABLED_KEY = "historyEnabled";
    let historyEntries = [];       // 内存缓存，避免频繁读 storage
    let historyEnabled = false;    // 内存缓存，playVideo() 时直接判断，不必每次都异步读取

    function pad2(n) {
        return n < 10 ? "0" + n : String(n);
    }
    // 生成默认标题：条目添加时间，精确到秒
    function formatHistoryTimestamp(ts) {
        const d = new Date(ts);
        return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate()) +
            " " + pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds());
    }
    function genHistoryId() {
        return "h_" + Date.now().toString(36) + "_" + Math.random().toString(36).slice(2, 8);
    }
    function sortHistoryEntries(list) {
        const pinned = list.filter(item => item.pinned).sort((a, b) => (b.editedAt || 0) - (a.editedAt || 0));
        const others = list.filter(item => !item.pinned).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        return pinned.concat(others);
    }
    function loadHistoryEnabledState() {
        chrome.storage.local.get([HISTORY_ENABLED_KEY], function(result) {
            historyEnabled = !!result[HISTORY_ENABLED_KEY];
            if (historyEnableToggle) historyEnableToggle.checked = historyEnabled;
        });
    }
    function saveHistoryEnabledState(enabled) {
        historyEnabled = enabled;
        const data = {};
        data[HISTORY_ENABLED_KEY] = enabled;
        chrome.storage.local.set(data, function() {
            if (chrome.runtime.lastError) {
                console.error(i18n.t("popup_history_save_fail_console"), chrome.runtime.lastError);
            }
        });
    }
    function loadHistoryEntries(callback) {
        chrome.storage.local.get([HISTORY_STORAGE_KEY], function(result) {
            if (chrome.runtime.lastError) {
                console.warn(i18n.t("popup_history_load_fail_console"), chrome.runtime.lastError);
                historyEntries = [];
            } else {
                historyEntries = Array.isArray(result[HISTORY_STORAGE_KEY]) ? result[HISTORY_STORAGE_KEY] : [];
            }
            if (typeof callback === "function") callback();
        });
    }
    function saveHistoryEntries(callback) {
        const data = {};
        data[HISTORY_STORAGE_KEY] = historyEntries;
        chrome.storage.local.set(data, function() {
            if (chrome.runtime.lastError) {
                console.error(i18n.t("popup_history_save_fail_console"), chrome.runtime.lastError);
            }
            if (typeof callback === "function") callback();
        });
    }
    function escapeHtmlLite(s) {
        return String(s == null ? "" : s)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;");
    }
    // 新增一条播放记录（仅在开关开启时调用）
    function addHistoryEntry(url) {
        if (!historyEnabled || !url) return;
        const now = Date.now();
        historyEntries.push({
            id: genHistoryId(),
            url: url,
            title: formatHistoryTimestamp(now),
            createdAt: now,
            editedAt: null,
            pinned: false
        });
        saveHistoryEntries(renderHistoryList);
    }
    // 渲染下拉框中的播放记录列表
    function renderHistoryList() {
        if (!historyList) return;
        const sorted = sortHistoryEntries(historyEntries);
        if (!sorted.length) {
            historyList.innerHTML = '<div class="history-empty">' + i18n.t("popup_history_empty") + "</div>";
            return;
        }
        historyList.innerHTML = sorted.map(function(item) {
            return '<div class="history-item' + (item.pinned ? ' pinned' : '') + '" data-id="' + item.id + '">' +
                '<div class="history-item-main">' +
                '<div class="history-item-title" data-i18n-edit-title="' + item.id + '">' + escapeHtmlLite(item.title) + "</div>" +
                '<div class="history-item-url">' + escapeHtmlLite(item.url) + "</div>" +
                "</div>" +
                '<button type="button" class="history-item-edit-btn" title="' + i18n.t("popup_history_edit_title") + '">&#9998;</button>' +
                '<button type="button" class="history-item-delete-btn" title="' + i18n.t("popup_history_delete_title") + '">&times;</button>' +
                "</div>";
        }).join("");
    }
    function openHistoryDropdown() {
        if (!historyDropdown) return;
        renderHistoryList();
        historyDropdown.hidden = false;
        if (historyDropdownToggle) {
            historyDropdownToggle.classList.add("open");
            historyDropdownToggle.setAttribute("aria-expanded", "true");
            historyDropdownToggle.textContent = "▴";
        }
    }
    function closeHistoryDropdown() {
        if (!historyDropdown) return;
        historyDropdown.hidden = true;
        if (historyDropdownToggle) {
            historyDropdownToggle.classList.remove("open");
            historyDropdownToggle.setAttribute("aria-expanded", "false");
            historyDropdownToggle.textContent = "▾";
        }
    }
    if (historyDropdownToggle) {
        historyDropdownToggle.addEventListener("click", function(e) {
            e.stopPropagation();
            if (historyDropdown.hidden) {
                openHistoryDropdown();
            } else {
                closeHistoryDropdown();
            }
        });
    }
    // 点击面板外部关闭下拉框
    document.addEventListener("click", function(e) {
        if (!historyDropdown || historyDropdown.hidden) return;
        if (!historyDropdown.contains(e.target) && e.target !== historyDropdownToggle) {
            closeHistoryDropdown();
        }
    });
    // 清空播放记录：只清除未被编辑过（未置顶）的条目，置顶条目只能通过条目自身的叉号删除
    if (historyClearBtn) {
        historyClearBtn.addEventListener("click", function(e) {
            e.stopPropagation();
            const clearable = historyEntries.filter(item => !item.pinned);
            if (!clearable.length) return;
            if (!window.confirm(i18n.t("popup_history_clear_confirm"))) return;
            historyEntries = historyEntries.filter(item => item.pinned);
            saveHistoryEntries(renderHistoryList);
        });
    }
    // 列表内的点击（选中 / 编辑 / 删除）使用事件委托统一处理
    if (historyList) {
        historyList.addEventListener("click", function(e) {
            const itemEl = e.target.closest(".history-item");
            if (!itemEl) return;
            const id = itemEl.getAttribute("data-id");
            // 删除条目：无论是否置顶都可以通过叉号删除
            if (e.target.closest(".history-item-delete-btn")) {
                e.stopPropagation();
                historyEntries = historyEntries.filter(item => item.id !== id);
                saveHistoryEntries(renderHistoryList);
                return;
            }
            // 进入标题编辑模式
            if (e.target.closest(".history-item-edit-btn")) {
                e.stopPropagation();
                const titleEl = itemEl.querySelector(".history-item-title");
                if (titleEl) startEditHistoryTitle(titleEl, id);
                return;
            }
            // 标题正在编辑中时，点击标题本身不应触发"选中此条目"的行为
            const titleEl = e.target.closest(".history-item-title");
            if (titleEl && titleEl.isContentEditable) {
                e.stopPropagation();
                return;
            }
            // 点击条目主体：直接播放该链接
            const entry = historyEntries.find(item => item.id === id);
            if (entry) {
                closeHistoryDropdown();
                playVideo(entry.url);
            }
        });
    }
    // 让某个条目的标题可编辑；编辑完成（失焦或回车）后提交：
    //   - 若新标题为空或与原标题相同，视为未编辑，不改变置顶状态；
    //   - 否则该条目被标记为置顶（pinned），并记录 editedAt 用于排序。
    function startEditHistoryTitle(titleEl, id) {
        const entry = historyEntries.find(item => item.id === id);
        if (!entry) return;
        const originalTitle = entry.title;
        titleEl.setAttribute("contenteditable", "true");
        titleEl.focus();
        // 选中全部文字，方便直接输入替换
        const range = document.createRange();
        range.selectNodeContents(titleEl);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);

        let committed = false;
        function commit() {
            if (committed) return;
            committed = true;
            titleEl.removeAttribute("contenteditable");
            const newTitle = titleEl.textContent.trim();
            if (newTitle && newTitle !== originalTitle) {
                entry.title = newTitle;
                entry.editedAt = Date.now();
                entry.pinned = true;
                saveHistoryEntries(renderHistoryList);
            } else {
                // 未做有效修改，恢复原标题显示
                titleEl.textContent = originalTitle;
            }
            titleEl.removeEventListener("blur", onBlur);
            titleEl.removeEventListener("keydown", onKeydown);
        }
        function onBlur() {
            commit();
        }
        function onKeydown(e) {
            if (e.key === "Enter") {
                e.preventDefault();
                titleEl.blur(); // 触发 onBlur -> commit
            } else if (e.key === "Escape") {
                e.preventDefault();
                titleEl.textContent = originalTitle;
                committed = true; // 跳过 commit 里的写入逻辑
                titleEl.removeAttribute("contenteditable");
                titleEl.removeEventListener("blur", onBlur);
                titleEl.removeEventListener("keydown", onKeydown);
            }
        }
        titleEl.addEventListener("blur", onBlur);
        titleEl.addEventListener("keydown", onKeydown);
    }
    // 新增：初始化播放记录数据与开关状态
    loadHistoryEnabledState();
    loadHistoryEntries();
    if (historyEnableToggle) {
        historyEnableToggle.addEventListener("change", function() {
            saveHistoryEnabledState(this.checked);
        });
    }
    // ================== 播放记录功能结束 ==================

    // 监听输入框的粘贴事件（自动播放链接）
    videoUrlInput.addEventListener('paste', function(e) {
        setTimeout(() => {
            const text = videoUrlInput.value.trim();
            if (text && (text.includes('.flv') || text.includes('.ts') || text.includes('.m3u8') || text.includes('.m3u'))) {
                playVideo(text);
            }
        }, 100);
    });
    // 监听输入框的回车键
    videoUrlInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const url = videoUrlInput.value.trim();
            if (url) {
                playVideo(url);
            }
        }
    });
    playBtn.addEventListener("click", function() {
        const url = videoUrlInput.value.trim();
        if (url) {
            playVideo(url);
        } else {
            alert(i18n.t("popup_invalid_url_alert"));
        }
    });
    function playVideo(url) {
        // 保存URL到storage
        // chrome.storage.local.set({ lastVideoUrl: url });
        addHistoryEntry(url); // 新增：若播放记录开关已开启，记录本次播放
        chrome.tabs.create({
            url: chrome.runtime.getURL("player.html") + "?url=" + encodeURIComponent(url)
        });
    }
    settingsBtn.addEventListener("click", () => {
      if (chrome.runtime.openOptionsPage) {
        chrome.runtime.openOptionsPage();
        window.close();  // 可选：关闭 popup
      } else {
        // 回退
        chrome.tabs.create({ url: chrome.runtime.getURL("settings.html") });
      }
    });
    // 从 manifest.json 读取版本号并显示
    const versionElement = document.querySelector('.version');
    if (versionElement) {
        try {
            const manifest = chrome.runtime.getManifest();
            if (manifest && manifest.version) {
                versionElement.textContent = `${manifest.version}`;
            } else {
                versionElement.textContent = "0.1"; // 默认值
            }
        } catch (error) {
            console.warn(i18n.t("popup_manifest_read_fail_console"), error);
            versionElement.textContent = "0.1"; // 默认值
        }
    }
    setTimeout(() => {
        videoUrlInput.focus();
        // 可选：videoUrlInput.select();
    }, 100);   // 50ms 通常足够
});