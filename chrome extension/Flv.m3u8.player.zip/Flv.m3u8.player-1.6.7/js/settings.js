// 屏蔽普通日志和信息
console.log = function() {};
console.info = function() {};
document.addEventListener("DOMContentLoaded", async function() {
    await i18n.ready; // 确保下面渲染的所有动态文案（空状态、toast、alert等）使用正确语言
    // ==================== 主题管理 ====================
    const THEME_KEY = 'fmplayer_theme';

    function applyTheme(theme) {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const isDark = theme === 'dark' || (theme === 'system' && prefersDark);
        document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
    }

    function loadTheme() {
        const saved = localStorage.getItem(THEME_KEY) || 'system';
        applyTheme(saved);
        const sel = document.getElementById('themeSelect');
        if (sel) sel.value = saved;
    }

    function saveTheme(theme) {
        localStorage.setItem(THEME_KEY, theme);
        applyTheme(theme);
    }

    // 监听系统主题变化（跟随系统模式下实时响应）
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
        const current = localStorage.getItem(THEME_KEY) || 'light';
        if (current === 'system') applyTheme('system');
    });

    loadTheme();
    // DOM 元素
    const tabs = document.querySelectorAll('.nav-item');
    const tabContents = document.querySelectorAll('.tab-content');
    const backBtn = document.querySelector('.back-btn');
    const saveBtn = document.getElementById('saveBtn');
    const resetBtn = document.getElementById('resetBtn');
    const blacklistInput = document.getElementById('blacklistInput');
    const addKeywordBtn = document.getElementById('addKeywordBtn');
    const blacklistItems = document.getElementById('blacklistItems');
    const testEpgBtn = document.getElementById('testEpgBtn');
    // 默认配置（用户友好的单位）
    const DEFAULT_CONFIG = {
        loadTimeout: 10, // 秒
        stallTimeout: 10, // 秒
        maxRetryRounds: 1, // 轮
        searchDebounce: 300, // 毫秒
        playlistRefreshInterval: 30, // 分钟
        autoRefreshEnabled: true,
        epgEnabled: false,
        epgUrl: 'http://e.erw.cc/e.xml.gz',
        marqueeSpeed: 100,
        marqueeColor: '#ffd700',
        marqueeFontSize: '20',
        blacklist: [],
        headerRules: []
    };
    let currentConfig = { ...DEFAULT_CONFIG
    };
    // ==================== 新增：自动刷新频道列表 UI 控制 ====================
    function updateAutoRefreshUIState() {
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        if (!autoRefreshEnabledInput) return;
        const isEnabled = autoRefreshEnabledInput.checked;
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        if (playlistRefreshIntervalInput) {
            playlistRefreshIntervalInput.disabled = !isEnabled;
            playlistRefreshIntervalInput.style.opacity = isEnabled ? '1' : '0.6';
        }
    }
    // ==================== 原有 EPG UI 控制 ====================
    function updateEpgUIState() {
        const epgEnabledInput = document.getElementById('epgEnabled');
        if (!epgEnabledInput) return;
        const isEpgEnabled = epgEnabledInput.checked;
        const epgUrlInput = document.getElementById('epgUrl');
        const marqueeSpeedInput = document.getElementById('marqueeSpeed');
        const marqueeColorContainer = document.querySelector('.color-picker-container');
        const marqueeFontSizeInput = document.getElementById('marqueeFontSize');
        const testEpgBtn = document.getElementById('testEpgBtn');
        [epgUrlInput, marqueeSpeedInput, marqueeFontSizeInput].forEach(input => {
            if (input) {
                input.disabled = !isEpgEnabled;
                input.style.opacity = isEpgEnabled ? '1' : '0.6';
            }
        });
        if (marqueeColorContainer) {
            const inputs = marqueeColorContainer.querySelectorAll('input');
            inputs.forEach(input => {
                input.disabled = !isEpgEnabled;
            });
            marqueeColorContainer.style.opacity = isEpgEnabled ? '1' : '0.6';
        }
        if (testEpgBtn) {
            testEpgBtn.disabled = !isEpgEnabled;
            testEpgBtn.style.opacity = isEpgEnabled ? '1' : '0.6';
        }
    }
    // 初始化标签页导航：瀑布流模式
    // 右侧所有设置区块（.tab-content）始终全部显示、可连续滚动；
    // 左侧标题不再需要点击才能显示内容，只负责：
    //   1) 点击后平滑滚动到对应区块
    //   2) 滚动过程中自动检测当前处于视口顶部附近的区块，高亮对应的左侧标题（scrollspy）
    function initTabs() {
        const scrollArea = document.querySelector('.content-scroll-area');
        const sectionList = Array.from(tabContents); // 与 tabs 顺序一一对应
        const pageTitle = document.getElementById('page-title');
        let suppressSpyUntil = 0; // 点击触发的滚动动画期间，暂停 scrollspy 判定，避免途中经过其它区块时高亮跳动
        let tickingScroll = false;

        function setActiveNavByTabId(tabId) {
            tabs.forEach(t => t.classList.toggle('active', t.getAttribute('data-tab') === tabId));
            const activeTab = Array.from(tabs).find(t => t.getAttribute('data-tab') === tabId);
            if (pageTitle && activeTab) pageTitle.textContent = activeTab.textContent;
        }

        // 判定当前"所处区块"：找到最后一个顶部已经越过判定线的区块
        function detectActiveSection() {
            if (!scrollArea || !sectionList.length) return;
            const areaTop = scrollArea.getBoundingClientRect().top;
            const triggerY = areaTop + 24; // 判定线：滚动区域顶部往下一点点
            let current = sectionList[0];
            for (const sec of sectionList) {
                if (sec.getBoundingClientRect().top - triggerY <= 0) {
                    current = sec;
                } else {
                    break;
                }
            }
            const tabId = current.id.replace('-tab', '');
            setActiveNavByTabId(tabId);
        }

        function onScroll() {
            if (Date.now() < suppressSpyUntil) return;
            if (tickingScroll) return;
            tickingScroll = true;
            window.requestAnimationFrame(() => {
                detectActiveSection();
                tickingScroll = false;
            });
        }

        if (scrollArea) {
            scrollArea.addEventListener('scroll', onScroll, { passive: true });
        }

        tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                const tabId = tab.getAttribute('data-tab');
                const targetTab = document.getElementById(`${tabId}-tab`);
                if (!targetTab) return;
                // 立即高亮点击项，滚动动画期间不再被 scrollspy 覆盖
                setActiveNavByTabId(tabId);
                suppressSpyUntil = Date.now() + 700;
                targetTab.scrollIntoView({ behavior: 'smooth', block: 'start' });
                // 移动端：点击菜单项后自动关闭侧边栏
                if (window.innerWidth <= 768) closeSidebar();
            });
        });

        // 初始状态：根据当前滚动位置高亮对应标题
        detectActiveSection();
    }
    // 初始化颜色选择器
    function initColorPicker() {
        const colorPicker = document.getElementById('marqueeColor');
        const colorText = document.getElementById('marqueeColorText');
        if (colorPicker && colorText) {
            colorPicker.addEventListener('input', (e) => {
                colorText.value = e.target.value;
            });
            colorText.addEventListener('input', (e) => {
                const value = e.target.value;
                if (/^#[0-9A-F]{6}$/i.test(value)) colorPicker.value = value;
            });
            colorText.addEventListener('blur', (e) => {
                let value = e.target.value.trim();
                if (!value.startsWith('#')) value = '#' + value;
                if (/^#[0-9A-F]{6}$/i.test(value)) {
                    colorPicker.value = value;
                    colorText.value = value;
                } else {
                    colorText.value = colorPicker.value;
                }
            });
        }
    }
    // 加载设置
    function loadSettings() {
        chrome.storage.local.get([
            'loadTimeout', 'stallTimeout', 'maxRetryRounds', 'searchDebounce',
            'playlistRefreshInterval', 'autoRefreshEnabled', 'epgEnabled', 'epgUrl',
            'marqueeSpeed', 'marqueeColor', 'marqueeFontSize', 'blacklist', 'headerRules'
        ], function(result) {
            const loadTimeoutInput = document.getElementById('loadTimeout');
            const stallTimeoutInput = document.getElementById('stallTimeout');
            const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
            const searchDebounceInput = document.getElementById('searchDebounce');
            const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
            const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
            const epgEnabledInput = document.getElementById('epgEnabled');
            const epgUrlInput = document.getElementById('epgUrl');
            const marqueeSpeedInput = document.getElementById('marqueeSpeed');
            const marqueeColorInput = document.getElementById('marqueeColor');
            const marqueeColorText = document.getElementById('marqueeColorText');
            const marqueeFontSizeInput = document.getElementById('marqueeFontSize');
            if (loadTimeoutInput) loadTimeoutInput.value = result.loadTimeout !== undefined ? Math.round(result.loadTimeout / 1000) : DEFAULT_CONFIG.loadTimeout;
            if (stallTimeoutInput) stallTimeoutInput.value = result.stallTimeout !== undefined ? Math.round(result.stallTimeout / 1000) : DEFAULT_CONFIG.stallTimeout;
            if (maxRetryRoundsInput) maxRetryRoundsInput.value = result.maxRetryRounds !== undefined ? result.maxRetryRounds : DEFAULT_CONFIG.maxRetryRounds;
            if (searchDebounceInput) searchDebounceInput.value = result.searchDebounce !== undefined ? result.searchDebounce : DEFAULT_CONFIG.searchDebounce;
            if (playlistRefreshIntervalInput) playlistRefreshIntervalInput.value = result.playlistRefreshInterval !== undefined ? Math.round(result.playlistRefreshInterval / 60000) : DEFAULT_CONFIG.playlistRefreshInterval;
            if (autoRefreshEnabledInput) autoRefreshEnabledInput.checked = result.autoRefreshEnabled !== undefined ? result.autoRefreshEnabled : DEFAULT_CONFIG.autoRefreshEnabled;
            if (epgEnabledInput) epgEnabledInput.checked = result.epgEnabled !== undefined ? result.epgEnabled : DEFAULT_CONFIG.epgEnabled;
            if (epgUrlInput) epgUrlInput.value = result.epgUrl !== undefined ? result.epgUrl : DEFAULT_CONFIG.epgUrl;
            if (marqueeSpeedInput) marqueeSpeedInput.value = result.marqueeSpeed !== undefined ? result.marqueeSpeed : DEFAULT_CONFIG.marqueeSpeed;
            if (marqueeColorInput && marqueeColorText) {
                const colorValue = result.marqueeColor !== undefined ? result.marqueeColor : DEFAULT_CONFIG.marqueeColor;
                marqueeColorInput.value = colorValue;
                marqueeColorText.value = colorValue;
            }
            if (marqueeFontSizeInput) marqueeFontSizeInput.value = result.marqueeFontSize !== undefined ? result.marqueeFontSize : DEFAULT_CONFIG.marqueeFontSize;
            // Update currentConfig to match UI values (Display Units)
            currentConfig.loadTimeout = loadTimeoutInput ? parseInt(loadTimeoutInput.value) : DEFAULT_CONFIG.loadTimeout;
            currentConfig.stallTimeout = stallTimeoutInput ? parseInt(stallTimeoutInput.value) : DEFAULT_CONFIG.stallTimeout;
            currentConfig.maxRetryRounds = maxRetryRoundsInput ? parseInt(maxRetryRoundsInput.value) : DEFAULT_CONFIG.maxRetryRounds;
            currentConfig.searchDebounce = searchDebounceInput ? parseInt(searchDebounceInput.value) : DEFAULT_CONFIG.searchDebounce;
            currentConfig.playlistRefreshInterval = playlistRefreshIntervalInput ? parseInt(playlistRefreshIntervalInput.value) : DEFAULT_CONFIG.playlistRefreshInterval;
            currentConfig.autoRefreshEnabled = autoRefreshEnabledInput ? autoRefreshEnabledInput.checked : DEFAULT_CONFIG.autoRefreshEnabled;
            currentConfig.epgEnabled = epgEnabledInput ? epgEnabledInput.checked : DEFAULT_CONFIG.epgEnabled;
            currentConfig.epgUrl = epgUrlInput ? epgUrlInput.value : DEFAULT_CONFIG.epgUrl;
            currentConfig.marqueeSpeed = marqueeSpeedInput ? parseFloat(marqueeSpeedInput.value) : DEFAULT_CONFIG.marqueeSpeed;
            currentConfig.marqueeColor = marqueeColorInput ? marqueeColorInput.value : DEFAULT_CONFIG.marqueeColor;
            currentConfig.marqueeFontSize = marqueeFontSizeInput ? marqueeFontSizeInput.value : DEFAULT_CONFIG.marqueeFontSize;
            if (result.blacklist && Array.isArray(result.blacklist)) {
                currentConfig.blacklist = result.blacklist;
            } else {
                loadBlacklistFromFile();
            }
            renderBlacklist();
            if (result.headerRules && Array.isArray(result.headerRules)) {
                currentConfig.headerRules = result.headerRules;
            } else {
                currentConfig.headerRules = [];
            }
            renderHeaderRules();
            updateEpgUIState();
            updateAutoRefreshUIState();
        });
    }
    // 从文件加载黑名单
    function loadBlacklistFromFile() {
        fetch(chrome.runtime.getURL('blacklist.txt'))
            .then(response => response.text())
            .then(text => {
                const keywords = text.split('\n')
                    .map(line => line.trim())
                    .filter(line => line && !line.startsWith('#') && !line.startsWith('//'))
                    .filter(keyword => keyword.length > 0);
                currentConfig.blacklist = keywords;
                renderBlacklist();
            })
            .catch(error => {
                console.warn(i18n.t('settings_console_blacklist_load_fail'), error);
                currentConfig.blacklist = [];
                renderBlacklist();
            });
    }
    // 渲染黑名单列表
    function renderBlacklist() {
        if (!blacklistItems) return;
        blacklistItems.innerHTML = '';
        if (currentConfig.blacklist.length === 0) {
            blacklistItems.innerHTML = `<div class="empty-state"><div>📝</div><p>${i18n.t('settings_blacklist_empty_title')}</p><p class="tip">${i18n.t('settings_blacklist_empty_tip')}</p></div>`;
            return;
        }
        currentConfig.blacklist.forEach((keyword, index) => {
            const item = document.createElement('div');
            item.className = 'blacklist-item';
            item.innerHTML = `<div class="blacklist-keyword">${escapeHtml(keyword)}</div><div class="blacklist-actions"><button class="edit-btn" data-index="${index}">✏️</button><button class="delete-btn" data-index="${index}">🗑️</button></div>`;
            blacklistItems.appendChild(item);
        });
		// 修正：将 document 改为 blacklistItems(这是该区域的父容器)
        blacklistItems.querySelectorAll('.edit-btn').forEach(btn => btn.addEventListener('click', e => editKeyword(parseInt(e.target.getAttribute('data-index')))));
        blacklistItems.querySelectorAll('.delete-btn').forEach(btn => btn.addEventListener('click', e => deleteKeyword(parseInt(e.target.getAttribute('data-index')))));
    }
    // 渲染 header rules
    function renderHeaderRules() {
        const container = document.getElementById('headerRulesItems');
        if (!container) return;
        container.innerHTML = '';
        if (currentConfig.headerRules.length === 0) {
            container.innerHTML = `<div class="empty-state"><div>🔐</div><p>${i18n.t('settings_headerrules_empty_title')}</p><p class="tip">${i18n.t('settings_headerrules_empty_tip')}</p></div>`;
            return;
        }
        currentConfig.headerRules.forEach((rule, index) => {
            const headersStr = Object.entries(rule.headers || {}).map(([k, v]) => `${k}: ${v}`).join('; ');
            const item = document.createElement('div');
            item.className = 'blacklist-item';
            item.innerHTML = `<div class="blacklist-keyword"><strong>pattern:</strong> ${escapeHtml(rule.pattern)}<br><strong>headers:</strong> ${escapeHtml(headersStr)}</div><div class="blacklist-actions"><button class="edit-btn" data-index="${index}">✏️</button><button class="delete-btn" data-index="${index}">🗑️</button></div>`;
            container.appendChild(item);
        });
        container.querySelectorAll('.edit-btn').forEach(btn => btn.addEventListener('click', e => editHeaderRule(parseInt(e.target.dataset.index))));
        container.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', e => {
                if (confirm(i18n.t('settings_confirm_delete_rule'))) {
                    currentConfig.headerRules.splice(parseInt(e.target.dataset.index), 1);
                    renderHeaderRules();
                    showMessage(i18n.t('settings_msg_rule_deleted'));
                }
            });
        });
    }
    // 添加关键词
    function addKeyword() {
        if (!blacklistInput) return;
        const keyword = blacklistInput.value.trim();
        if (!keyword) {
            alert(i18n.t('settings_alert_enter_keyword'));
            return;
        }
        if (currentConfig.blacklist.includes(keyword)) {
            alert(i18n.t('settings_alert_keyword_exists'));
            return;
        }
        currentConfig.blacklist.push(keyword);
        blacklistInput.value = '';
        renderBlacklist();
        showMessage(i18n.t('settings_msg_keyword_added'));
    }
    function editKeyword(index) {
        const oldKeyword = currentConfig.blacklist[index];
        const newKeyword = prompt(i18n.t('settings_prompt_edit_keyword'), oldKeyword);
        if (newKeyword !== null) {
            const trimmedKeyword = newKeyword.trim();
            if (trimmedKeyword && !currentConfig.blacklist.includes(trimmedKeyword)) {
                currentConfig.blacklist[index] = trimmedKeyword;
                renderBlacklist();
                showMessage(i18n.t('settings_msg_keyword_updated'));
            } else if (!trimmedKeyword) alert(i18n.t('settings_alert_keyword_empty'));
            else alert(i18n.t('settings_alert_keyword_exists'));
        }
    }
    function deleteKeyword(index) {
        if (confirm(i18n.t('settings_confirm_delete_keyword'))) {
            currentConfig.blacklist.splice(index, 1);
            renderBlacklist();
            showMessage(i18n.t('settings_msg_keyword_deleted'));
        }
    }
    // 解析 headers
    function parseHeaders(str) {
        const headers = {};
        let i = 0,
            len = str.length;
        while (i < len) {
            while (i < len && /\s/.test(str[i])) i++;
            if (i >= len) break;
            let keyStart = i;
            while (i < len && str[i] !== ':') i++;
            let key = str.substring(keyStart, i).trim();
            if (i < len) i++;
            while (i < len && /\s/.test(str[i])) i++;
            let value = '';
            if (i < len && (str[i] === '"' || str[i] === "'")) {
                const quote = str[i];
                i++;
                let escapedValue = '';
                while (i < len) {
                    if (str[i] === '\\') {
                        i++;
                        if (i < len) escapedValue += str[i++];
                        continue;
                    }
                    if (str[i] === quote) {
                        value = escapedValue;
                        i++;
                        break;
                    }
                    escapedValue += str[i++];
                }
            } else {
                let start = i;
                while (i < len && str[i] !== ';') i++;
                value = str.substring(start, i).trim();
            }
            if (key) headers[key] = value;
            while (i < len && (str[i] === ';' || /\s/.test(str[i]))) i++;
        }
        return headers;
    }
    function addHeaderRule() {
        const patternInput = document.getElementById('rulePatternInput');
        const headersInput = document.getElementById('ruleHeadersInput');
        if (!patternInput || !headersInput) return;
        const pattern = patternInput.value.trim();
        const headersStr = headersInput.value.trim();
        if (!pattern) {
            alert(i18n.t('settings_alert_enter_pattern'));
            return;
        }
        if (!headersStr) {
            alert(i18n.t('settings_alert_enter_headers'));
            return;
        }
        const headers = parseHeaders(headersStr);
        if (Object.keys(headers).length === 0) {
            alert(i18n.t('settings_alert_no_valid_headers'));
            return;
        }
        currentConfig.headerRules.push({
            pattern,
            headers
        });
        patternInput.value = '';
        headersInput.value = '';
        renderHeaderRules();
        showMessage(i18n.t('settings_msg_rule_added'));
    }
    function editHeaderRule(index) {
        const rule = currentConfig.headerRules[index];
        if (!rule) return;
        const headersStr = Object.entries(rule.headers).map(([k, v]) => `${k}: ${v}`).join('; ');
        const newInput = prompt(i18n.t('settings_prompt_edit_rule'), `${rule.pattern} | ${headersStr}`);
        if (newInput === null) return;
        const [newPatternPart, newHeadersPart] = newInput.split('|').map(s => s.trim());
        if (!newPatternPart || !newHeadersPart) {
            alert(i18n.t('settings_alert_rule_format_error'));
            return;
        }
        const newHeaders = parseHeaders(newHeadersPart);
        if (Object.keys(newHeaders).length === 0) {
            alert(i18n.t('settings_alert_no_valid_header'));
            return;
        }
        currentConfig.headerRules[index] = {
            pattern: newPatternPart,
            headers: newHeaders
        };
        renderHeaderRules();
        showMessage(i18n.t('settings_msg_rule_updated'));
    }
    // 测试EPG数据源（保持完整）
    // background.js 那边测试 EPG 数据源失败时，返回的是稳定的错误码字符串（不是本地化好的文案），
    // 这里统一翻译成当前界面语言；遇到未知的 code（比如浏览器原生 fetch 抛出的网络错误信息）就原样显示。
    function translateEpgErrorCode(code) {
        const map = {
            'ERR_EPG_TIMEOUT': 'settings_epg_err_timeout',
            'ERR_INVALID_XML': 'settings_epg_err_invalid_xml',
            'ERR_NO_PROGRAMS': 'settings_epg_err_no_programs',
            'ERR_XML_PARSE': 'settings_epg_err_xml_parse',
            'ERR_INVALID_URL': 'settings_epg_err_invalid_url',
            'ERR_URL_FORMAT': 'settings_epg_err_url_format',
            'ERR_EPG_TEST_FAILED': 'settings_msg_epg_test_failed',
        };
        return map[code] ? i18n.t(map[code]) : code;
    }
    function testEpgDataSource() {
        const epgUrlInput = document.getElementById('epgUrl');
        const epgTestResult = document.getElementById('epgTestResult');
        const epgPreview = document.getElementById('epgPreview');
        if (!epgUrlInput || !epgUrlInput.value.trim()) {
            showMessage(i18n.t('settings_msg_enter_epg_url'), false);
            return;
        }
        const url = epgUrlInput.value.trim();
        epgTestResult.textContent = i18n.t('settings_status_testing_epg');
        epgTestResult.style.color = '#2196F3';
        epgPreview.innerHTML = `<div class="empty-state"><div>⏳</div><p>${i18n.t('settings_epg_loading_title')}</p><p class="tip">${i18n.t('settings_epg_loading_tip')}</p></div>`;
        chrome.runtime.sendMessage({
            action: 'testEpgUrl',
            url: url
        }, function(response) {
            if (chrome.runtime.lastError) {
                epgTestResult.textContent = i18n.t('settings_epg_test_fail_prefix', { MSG: chrome.runtime.lastError.message });
                epgTestResult.style.color = '#f44336';
                showMessage(i18n.t('settings_msg_epg_test_failed'), false);
                return;
            }
            if (response && response.success) {
                epgTestResult.textContent = i18n.t('settings_epg_test_success_text');
                epgTestResult.style.color = '#4CAF50';
                showMessage(i18n.t('settings_msg_epg_test_success'));
                if (response.data && response.data.length > 0) {
                    let previewHTML = `<div style="margin-bottom: 10px; color: #666; font-size: 12px;">${i18n.t('settings_epg_loaded_count', { N: response.data.length })}</div>`;
                    response.data.slice(0, 5).forEach(item => {
                        const startTime = item.start ? new Date(item.start).toLocaleTimeString(i18n.locale === 'zh_CN' ? 'zh-CN' : 'en-US', {
                            hour: '2-digit',
                            minute: '2-digit'
                        }) : '--:--';
                        const endTime = item.stop ? new Date(item.stop).toLocaleTimeString(i18n.locale === 'zh_CN' ? 'zh-CN' : 'en-US', {
                            hour: '2-digit',
                            minute: '2-digit'
                        }) : '--:--';
                        previewHTML += `<div class="epg-preview-item"><div class="epg-preview-time">${startTime} - ${endTime}</div><div class="epg-preview-title">${escapeHtml(item.title || i18n.t('settings_epg_unknown_program'))}</div></div>`;
                    });
                    epgPreview.innerHTML = previewHTML;
                }
            } else {
                const errorMsg = response && response.error ? translateEpgErrorCode(response.error) : i18n.t('settings_epg_unknown_error');
                epgTestResult.textContent = i18n.t('settings_epg_test_fail_text_prefix', { MSG: errorMsg });
                epgTestResult.style.color = '#f44336';
                showMessage(i18n.t('settings_msg_epg_test_failed_with_msg', { MSG: errorMsg }), false);
            }
        });
    }
    // 保存设置（完整）
    function saveSettings() {
        const loadTimeoutInput = document.getElementById('loadTimeout');
        const stallTimeoutInput = document.getElementById('stallTimeout');
        const maxRetryRoundsInput = document.getElementById('maxRetryRounds');
        const searchDebounceInput = document.getElementById('searchDebounce');
        const playlistRefreshIntervalInput = document.getElementById('playlistRefreshInterval');
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        const epgEnabledInput = document.getElementById('epgEnabled');
        const epgUrlInput = document.getElementById('epgUrl');
        const marqueeSpeedInput = document.getElementById('marqueeSpeed');
        const marqueeColorInput = document.getElementById('marqueeColor');
        const marqueeFontSizeInput = document.getElementById('marqueeFontSize');
        const loadTimeout = parseInt(loadTimeoutInput.value);
        const stallTimeout = parseInt(stallTimeoutInput.value);
        const maxRetryRounds = parseInt(maxRetryRoundsInput.value);
        const searchDebounce = parseInt(searchDebounceInput.value);
        const playlistRefreshInterval = parseInt(playlistRefreshIntervalInput.value);
        const autoRefreshEnabled = autoRefreshEnabledInput.checked;
        const epgEnabled = epgEnabledInput.checked;
        const epgUrl = epgUrlInput.value.trim();
        const marqueeSpeed = parseFloat(marqueeSpeedInput.value);
        const marqueeColor = marqueeColorInput.value.trim();
        const marqueeFontSize = marqueeFontSizeInput.value.trim();
        // 验证（与原代码一致）
        if (isNaN(loadTimeout) || loadTimeout < 1) {
            alert(i18n.t('settings_alert_load_timeout_min'));
            return;
        }
        if (isNaN(stallTimeout) || stallTimeout < 1) {
            alert(i18n.t('settings_alert_stall_timeout_min'));
            return;
        }
        if (isNaN(maxRetryRounds) || maxRetryRounds < 1) {
            alert(i18n.t('settings_alert_max_retry_min'));
            return;
        }
        if (isNaN(searchDebounce) || searchDebounce < 100) {
            alert(i18n.t('settings_alert_search_debounce_min'));
            return;
        }
        if (isNaN(playlistRefreshInterval) || playlistRefreshInterval < 5) {
            alert(i18n.t('settings_alert_refresh_interval_min'));
            return;
        }
        if (epgEnabled && !epgUrl) {
            alert(i18n.t('settings_alert_epg_url_required'));
            return;
        }
        if (marqueeSpeed < 50 || marqueeSpeed > 500) {
            alert(i18n.t('settings_alert_marquee_speed_range'));
            return;
        }
        if (!/^#[0-9A-F]{6}$/i.test(marqueeColor)) {
            alert(i18n.t('settings_alert_invalid_color'));
            return;
        }
        if (!/^\d+$/.test(marqueeFontSize)) {
            alert(i18n.t('settings_alert_invalid_font_size'));
            return;
        }
        const configToSave = {
            loadTimeout: loadTimeout * 1000,
            stallTimeout: stallTimeout * 1000,
            maxRetryRounds,
            searchDebounce,
            playlistRefreshInterval: playlistRefreshInterval * 60000,
            autoRefreshEnabled,
            epgEnabled,
            epgUrl,
            marqueeSpeed,
            marqueeColor,
            marqueeFontSize,
            blacklist: [...currentConfig.blacklist],
            headerRules: currentConfig.headerRules.map(r => ({ ...r,
                headers: { ...r.headers
                }
            }))
        };
        chrome.storage.local.set(configToSave, function() {
            showMessage(i18n.t('settings_msg_saved'), true);
            currentConfig.loadTimeout = loadTimeout;
            currentConfig.stallTimeout = stallTimeout;
            currentConfig.maxRetryRounds = maxRetryRounds;
            currentConfig.searchDebounce = searchDebounce;
            currentConfig.playlistRefreshInterval = playlistRefreshInterval;
            currentConfig.autoRefreshEnabled = autoRefreshEnabled;
            currentConfig.epgEnabled = epgEnabled;
            currentConfig.epgUrl = epgUrl;
            currentConfig.marqueeSpeed = marqueeSpeed;
            currentConfig.marqueeColor = marqueeColor;
            currentConfig.marqueeFontSize = marqueeFontSize;
            chrome.runtime.sendMessage({
                action: 'settingsUpdated',
                config: configToSave
            });
            chrome.runtime.sendMessage({
                action: 'updateHeaderRules'
            });
        });
    }
    // 恢复默认设置
    function resetSettings() {
        if (!confirm(i18n.t('settings_confirm_reset'))) return;
        document.getElementById('loadTimeout').value = DEFAULT_CONFIG.loadTimeout;
        document.getElementById('stallTimeout').value = DEFAULT_CONFIG.stallTimeout;
        document.getElementById('maxRetryRounds').value = DEFAULT_CONFIG.maxRetryRounds;
        document.getElementById('searchDebounce').value = DEFAULT_CONFIG.searchDebounce;
        document.getElementById('playlistRefreshInterval').value = DEFAULT_CONFIG.playlistRefreshInterval;
        document.getElementById('autoRefreshEnabled').checked = DEFAULT_CONFIG.autoRefreshEnabled;
        document.getElementById('epgEnabled').checked = DEFAULT_CONFIG.epgEnabled;
        document.getElementById('epgUrl').value = DEFAULT_CONFIG.epgUrl;
        document.getElementById('marqueeSpeed').value = DEFAULT_CONFIG.marqueeSpeed;
        document.getElementById('marqueeColor').value = DEFAULT_CONFIG.marqueeColor;
        document.getElementById('marqueeColorText').value = DEFAULT_CONFIG.marqueeColor;
        document.getElementById('marqueeFontSize').value = DEFAULT_CONFIG.marqueeFontSize;
        currentConfig = { ...DEFAULT_CONFIG
        };
        renderBlacklist();
        renderHeaderRules();
        updateEpgUIState();
        updateAutoRefreshUIState();
        chrome.storage.local.clear(function() {
            showMessage(i18n.t('settings_msg_reset_done'));
        });
    }
    function showMessage(message, isSuccess = true) {
        const existing = document.querySelector('.message-toast');
        if (existing) existing.remove();
        const div = document.createElement('div');
        div.className = `message-toast ${isSuccess ? 'success' : 'info'}`;
        div.textContent = message;
        div.style.cssText = `position:fixed;top:20px;right:20px;padding:12px 24px;background:${isSuccess?'#4CAF50':'#FF9800'};color:white;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);z-index:1000;animation:slideIn 0.3s ease;`;
        document.body.appendChild(div);
        setTimeout(() => {
            if (div.parentNode) div.remove();
        }, 3000);
    }
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    function addInputValidation() {
        document.querySelectorAll('input[type="number"]').forEach(input => {
            input.addEventListener('change', function() {
                const min = parseFloat(this.min) || 1;
                const max = parseFloat(this.max) || 9999;
                let value = parseFloat(this.value);
                if (isNaN(value)) this.value = min;
                else if (value < min) this.value = min;
                else if (value > max) this.value = max;
            });
        });
    }
    function exportSettings() {
        const data = JSON.stringify(currentConfig);
        const blob = new Blob([data], {
            type: 'application/json'
        });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.download = 'fmplayer_settings.json';
        a.href = url;
        a.click();
        URL.revokeObjectURL(url);
        showMessage(i18n.t('settings_msg_exported'));
    }
    function importSettings(event) {
        // 直接从事件目标获取文件
        const file = event.target.files[0];
        if (!file) {
            // 用户取消了选择
            return;
        }
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedConfig = JSON.parse(e.target.result);
                currentConfig = { ...DEFAULT_CONFIG,
                    ...importedConfig
                };
                document.getElementById('loadTimeout').value = currentConfig.loadTimeout;
                document.getElementById('stallTimeout').value = currentConfig.stallTimeout;
                document.getElementById('maxRetryRounds').value = currentConfig.maxRetryRounds;
                document.getElementById('searchDebounce').value = currentConfig.searchDebounce;
                document.getElementById('playlistRefreshInterval').value = currentConfig.playlistRefreshInterval;
                document.getElementById('autoRefreshEnabled').checked = currentConfig.autoRefreshEnabled;
                document.getElementById('epgEnabled').checked = currentConfig.epgEnabled;
                document.getElementById('epgUrl').value = currentConfig.epgUrl;
                document.getElementById('marqueeSpeed').value = currentConfig.marqueeSpeed;
                document.getElementById('marqueeColor').value = currentConfig.marqueeColor;
                document.getElementById('marqueeColorText').value = currentConfig.marqueeColor;
                document.getElementById('marqueeFontSize').value = currentConfig.marqueeFontSize;
                renderBlacklist();
                renderHeaderRules();
                updateEpgUIState();
                updateAutoRefreshUIState();
                showMessage(i18n.t('settings_msg_imported'));
                // 导入完成后清空输入框，以便能够再次导入同一个文件
                //event.target.value = '';
            } catch (err) {
                showMessage(i18n.t('settings_msg_import_failed'), false);
                event.target.value = '';
            }
        };
        reader.readAsText(file);
    }
    // 汉堡菜单逻辑
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if (sidebar && overlay) {
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }
    }
    function closeSidebar() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if (sidebar && overlay) {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
        }
    }
    // 初始化
    function init() {
        initTabs();
        initColorPicker();
        addInputValidation();
        loadSettings();
        const menuToggle = document.getElementById('menuToggle');
        if (menuToggle) menuToggle.addEventListener('click', toggleSidebar);
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        if (sidebarOverlay) sidebarOverlay.addEventListener('click', closeSidebar);
        if (backBtn) backBtn.addEventListener('click', () => window.close());
        if (saveBtn) saveBtn.addEventListener('click', saveSettings);
        if (resetBtn) resetBtn.addEventListener('click', resetSettings);
        if (addKeywordBtn) addKeywordBtn.addEventListener('click', addKeyword);
        if (testEpgBtn) testEpgBtn.addEventListener('click', testEpgDataSource);
        const addRuleBtn = document.getElementById('addRuleBtn');
        if (addRuleBtn) addRuleBtn.addEventListener('click', addHeaderRule);
        const epgEnabledInput = document.getElementById('epgEnabled');
        if (epgEnabledInput) epgEnabledInput.addEventListener('change', updateEpgUIState);
        // 新增：自动刷新监听
        const autoRefreshEnabledInput = document.getElementById('autoRefreshEnabled');
        if (autoRefreshEnabledInput) autoRefreshEnabledInput.addEventListener('change', updateAutoRefreshUIState);
        document.getElementById('exportSettingsBtn')?.addEventListener('click', exportSettings);
        // 主题下拉框监听
        const themeSelect = document.getElementById('themeSelect');
        if (themeSelect) {
            themeSelect.addEventListener('change', (e) => saveTheme(e.target.value));
        }
        // 修改：改为监听文件选择框的 change 事件，实现选择文件即自动导入
        const importInput = document.getElementById('importSettingsInput');
        if (importInput) {
            importInput.addEventListener('change', importSettings);
        }
        if (blacklistInput) {
            blacklistInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') addKeyword();
            });
        }
        // 为 Header 规则输入框添加回车监听
        const headersInput = document.getElementById('ruleHeadersInput');
        if (headersInput) {
            headersInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') addHeaderRule();
            });
        }
        chrome.runtime.onMessage.addListener((message) => {
            if (message.action === 'updateBlacklist') {
                currentConfig.blacklist = message.blacklist || [];
                renderBlacklist();
                showMessage(i18n.t('settings_msg_blacklist_updated'));
            }
            if (message.action === 'settingsUpdated') {
                loadSettings();
                showMessage(i18n.t('settings_msg_settings_updated'));
            }
        });
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
});