'use strict';
/**
 * js/soda-panel.js
 *
 * 实时字幕控制面板的 UI 交互逻辑：
 *   · 语言选择下拉框（候选表来自 SodaAsr.LANGS）
 *   · 所选语言的离线模型状态检测（可用 / 需下载 / 下载中 / 不可用）+ 下载按钮
 *   · "开启字幕 / 停止字幕"切换按钮
 *
 * 依赖 js/soda-asr.js 先加载（提供 window.SodaAsr）。
 * player.js 把 _startSodaAsr / _stopSodaAsr / state 挂到 window，本文件只调用它们。
 *
 * 替代原 whisper-ui.js（Whisper 模型/推理设备选择面板，已删除）。
 */
(function () {
    document.addEventListener('DOMContentLoaded', function () {

        var panel     = document.getElementById('whisper-panel');
        var toggleBtn = document.getElementById('whisper-toggle-btn');
        var langSel   = document.getElementById('soda-lang-select');
        var badge     = document.getElementById('soda-lang-status-badge');
        var dlBtn     = document.getElementById('soda-lang-download-btn');
        var statusEl  = document.getElementById('whisper-status-text');

        if (!panel || !toggleBtn || !langSel || !badge || !dlBtn) return;

        var LANGS = (window.SodaAsr && window.SodaAsr.LANGS) || [];
        var currentStatus = 'unsupported';
        var checkToken = 0; // 防止并发检测时旧结果覆盖新结果

        // ── 填充语言下拉框 ─────────────────────────────────────────
        LANGS.forEach(function (l) {
            var opt = document.createElement('option');
            opt.value = l.code;
            opt.textContent = l.label;
            langSel.appendChild(opt);
        });
        // 默认优先中文（若候选表里有）
        var zh = LANGS.filter(function (l) { return l.code === 'zh-CN'; })[0];
        if (zh) langSel.value = zh.code;
        if (window.state && window.state.whisper) {
            window.state.whisper.language = langSel.value;
        }

        function setBadge(status) {
            currentStatus = status;
            badge.className = 'soda-badge ' + status;
            dlBtn.style.display = 'none';
            switch (status) {
                case 'available':
                    badge.textContent = '✓ 已就绪';
                    break;
                case 'downloadable':
                    badge.textContent = '需下载';
                    dlBtn.style.display = 'inline-block';
                    dlBtn.disabled = false;
                    dlBtn.textContent = '下载模型';
                    break;
                case 'downloading':
                    badge.textContent = '下载中…';
                    dlBtn.style.display = 'inline-block';
                    dlBtn.disabled = true;
                    dlBtn.textContent = '下载中…';
                    break;
                case 'unavailable':
                    badge.textContent = '✗ 不可用';
                    break;
                case 'unsupported':
                default:
                    badge.textContent = '✗ 浏览器不支持';
                    break;
            }
            if (window.state && window.state.whisper) {
                window.state.whisper.langStatus = status;
            }
        }

        function refreshStatus() {
            if (!window.SodaAsr) return;
            var token = ++checkToken;
            badge.className = 'soda-badge checking';
            badge.textContent = '检测中…';
            dlBtn.style.display = 'none';
            window.SodaAsr.checkAvailability(langSel.value).then(function (st) {
                if (token !== checkToken) return; // 语言已经切换，丢弃过期结果
                setBadge(st);
            });
        }

        langSel.addEventListener('change', function () {
            if (window.state && window.state.whisper) {
                window.state.whisper.language = langSel.value;
            }
            refreshStatus();
        });

        // ── 下载按钮：必须直接在点击回调的同步链路内调用 install() ──────
        // （中间不能先 await 别的东西，否则浏览器会拒绝：
        //   "Requires handling a user gesture"）
        dlBtn.addEventListener('click', function () {
            var lang = langSel.value;
            setBadge('downloading');
            window.SodaAsr.installLang(lang).then(function (ok) {
                if (langSel.value !== lang) return; // 下载期间用户切换了语言，忽略
                refreshStatus();
                if (!ok && statusEl) {
                    statusEl.textContent = '模型下载失败，请重试';
                }
            });
        });

        // ── 点击面板外关闭 ─────────────────────────────────────────
        document.addEventListener('click', function (e) {
            var whisperBtn = document.getElementById('whisperBtn');
            if (!panel.contains(e.target) && !(whisperBtn && whisperBtn.contains(e.target))) {
                panel.classList.remove('show');
            }
        });

        // 每次打开面板时刷新一次状态（模型可能是浏览器后台下载完成的）
        var whisperBtnEl = document.getElementById('whisperBtn');
        if (whisperBtnEl) {
            whisperBtnEl.addEventListener('click', function () {
                if (panel.classList.contains('show')) refreshStatus();
            });
        }

        // ── 开启 / 停止 ───────────────────────────────────────────
        toggleBtn.addEventListener('click', function () {
            var whisperBtn = document.getElementById('whisperBtn');
            var enabled = window.state && window.state.whisper && window.state.whisper.enabled;

            if (enabled) {
                if (typeof window._stopSodaAsr === 'function') window._stopSodaAsr();
                toggleBtn.textContent = '开启字幕';
                toggleBtn.classList.remove('active');
                if (whisperBtn) whisperBtn.classList.remove('active');
                return;
            }

            if (currentStatus !== 'available') {
                if (statusEl) statusEl.textContent = '请先确认所选语言的离线模型已下载';
                return;
            }
            if (window.state && window.state.whisper) {
                window.state.whisper.language = langSel.value;
            }
            if (typeof window._startSodaAsr === 'function') window._startSodaAsr();
            toggleBtn.textContent = '停止字幕';
            toggleBtn.classList.add('active');
            if (whisperBtn) whisperBtn.classList.add('active');
        });

        // 初始检测一次
        refreshStatus();
    });
})();