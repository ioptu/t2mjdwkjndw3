/**
 * js/soda-translate.js  (ES Module，注意 <script type="module"> 加载)
 *
 * 用本地 HY-MT1.5-1.8B-ONNX（transformers.js + onnxruntime-web，webgpu + q4）
 * 替代浏览器内置的 Translator API。配置和 prompt 模板参考自另一个已验证
 * 可用的姊妹扩展（offscreen.js）里的同一套方案，原样搬过来。
 *
 * 与 Chrome 内置 Translator API 的关键差异（调用方 player.js 需要知道）：
 *   · 这是 text-generation pipeline，不是专用 MT 模型，走 prompt 模板而不是
 *     Translator.create({sourceLanguage,targetLanguage}) 那种按语言对创建实例；
 *   · 目标语言要传完整英文语言名（"Chinese"），不是语言代码；
 *   · 模型体积 GB 级（q4 量化约 1.4GB），首次使用要等下载，用
 *     progress_callback 上报下载进度；
 *   · 自回归生成比专用 MT 模型慢得多，只应该在“定稿”文本上调用，
 *     不要对着还在变化的未定稿文字反复调用。
 *
 * 已知风险（按你的决定，直接用官方默认配置 webgpu+q4，不做静默降级）：
 * int4 量化 decoder 在 WebGPU 后端可能撞上 ONNX Runtime Web 的
 * 8-storage-buffer 限制（Qwen3-ASR 那条管线上踩过的同一个坑）。这里不吞掉
 * 错误，pipeline 创建失败会把真实错误通过 reject 抛给调用方。
 */

import { pipeline, env } from '../transformers-bundle.js';

// ── transformers.js / onnxruntime-web 在 MV3 扩展环境下的固定配置 ──────
// 显式指向扩展本地文件，避免 transformers.js 默认去 jsDelivr CDN 拉取
// onnxruntime-web 运行时（ort-wasm-simd-threaded.asyncify.{mjs,wasm}），
// MV3 的 CSP（script-src 'self'）不允许加载远程脚本。
env.backends.onnx.wasm.wasmPaths = chrome.runtime.getURL('/');
// 扩展环境没有 COOP/COEP 跨域隔离头，onnxruntime-web 多线程 WASM 有已知 bug。
env.backends.onnx.wasm.numThreads = 1;
// 避免 onnxruntime-web 额外开 Worker 代理，重新走一遍脚本加载（可能不会
// 继承上面设置的 wasmPaths，导致同样的 CDN 加载问题在 Worker 里再犯一次）。
env.backends.onnx.wasm.proxy = false;
// 扩展里不存在 env.localModelPath 那种本地模型目录，跳过无意义的检查。
env.allowLocalModels = false;
// 模型权重下载源换成 modelscope.cn（国内网络更容易稳定访问）。
// remotePathTemplate 保持官方默认值不变，只换 host。
env.remoteHost = 'https://modelscope.cn';
env.remotePathTemplate = '{model}/resolve/{revision}/';

const MODEL_ID = 'onnx-community/HY-MT1.5-1.8B-ONNX';

const TARGET_LANG_NAMES = {
    zh: 'Chinese', en: 'English', ja: 'Japanese', ko: 'Korean',
    fr: 'French',  de: 'German',  es: 'Spanish',  ru: 'Russian',
    it: 'Italian', pt: 'Portuguese',
};
function toFullLangName(lang) {
    return TARGET_LANG_NAMES[lang] || lang;
}

let translatorPipeline        = null;
let translatorPipelinePromise = null;

/**
 * 加载（若尚未加载）并返回翻译 pipeline。
 * @param {(progress: object) => void} [onProgress] 下载/加载进度回调
 */
function ensureTranslatorPipeline(onProgress) {
    if (translatorPipeline) return Promise.resolve(translatorPipeline);
    if (!translatorPipelinePromise) {
        translatorPipelinePromise = pipeline('text-generation', MODEL_ID, {
            dtype: 'q4',
            device: 'webgpu',
            progress_callback: (p) => {
                try { onProgress && onProgress(p); } catch (_) {}
            },
        }).then((p) => {
            translatorPipeline = p;
            console.log('[SodaTranslate] 翻译模型加载完成');
            return p;
        }).catch((err) => {
            // 失败后允许下次重新尝试，而不是永久卡死
            translatorPipelinePromise = null;
            console.error('[SodaTranslate] 翻译模型加载失败:', err);
            throw err;
        });
    }
    return translatorPipelinePromise;
}

// 上下文感知翻译：把最近几段"已定稿的原文"作为上下文，帮助消解歧义、
// 保持术语/指代一致性。默认关闭（0 = 关闭），需要时可以调大。
const CONTEXT_WINDOW = 0;
let recentOriginals = [];

/**
 * 翻译一段已经"定稿"的文本。
 * @param {string} text        待翻译原文
 * @param {string} sourceLang  源语言简写（'en'/'ja'/... ），仅用于短路判断，不影响 prompt
 * @param {string} [targetLang='zh'] 目标语言简写
 * @param {{onProgress?: Function}} [opts]
 * @returns {Promise<string>} 译文；源语言=目标语言或文本为空时返回 ''
 */
async function translate(text, sourceLang, targetLang, opts) {
    targetLang = targetLang || 'zh';
    opts = opts || {};
    if (!text || !text.trim()) return '';
    if (sourceLang === targetLang) return '';

    const generator = await ensureTranslatorPipeline(opts.onProgress);

    const targetLangName = toFullLangName(targetLang);
    const context = CONTEXT_WINDOW > 0 ? recentOriginals.slice(-CONTEXT_WINDOW).join('\n') : '';
    const promptContent = context
        ? `${context}\n参考上面的信息，把下面的文本翻译成${targetLangName}，注意不需要翻译上文，也不要额外解释：\n${text}`
        : `Translate the following segment into ${targetLangName}, without additional explanation.\n\n${text}`;

    const messages = [{ role: 'user', content: promptContent }];

    // max_new_tokens 按字幕场景调小（官方示例给的 512 是给长文档用的，
    // 我们这里是单句口语字幕，不需要生成那么长，调小能直接降低单次延迟）。
    const output = await generator(messages, {
        max_new_tokens: 256,
        do_sample: false,
    });
    const result = (output && output[0] && output[0].generated_text &&
        output[0].generated_text.at(-1) && output[0].generated_text.at(-1).content || '').trim();

    if (result && CONTEXT_WINDOW > 0) {
        recentOriginals.push(text);
        if (recentOriginals.length > CONTEXT_WINDOW) recentOriginals.shift();
    }
    return result;
}

// 新一轮字幕会话开始（换台/重新开启字幕）时调用，避免上下文跨会话串台
function resetContext() {
    recentOriginals = [];
}

function isReady() {
    return !!translatorPipeline;
}

/**
 * 释放翻译模型占用的资源（WebGPU buffer / ORT session）。
 * 调用后 isReady() 变回 false，下次 translate() 会重新走一遍模型加载
 * （权重本身走浏览器缓存，不用重新下载，但 WebGPU session 需要重建，
 * 会有几秒的重新加载耗时——这是"关闭翻译时释放资源"这个需求本身的取舍）。
 */
async function dispose() {
    const p = translatorPipeline;
    translatorPipeline        = null;
    translatorPipelinePromise = null;
    recentOriginals = [];
    if (p && p.model && typeof p.model.dispose === 'function') {
        try {
            await p.model.dispose();
            console.log('[SodaTranslate] 翻译模型资源已释放');
        } catch (e) {
            console.warn('[SodaTranslate] dispose 失败:', e);
        }
    }
}

window.SodaTranslate = { translate, resetContext, isReady, dispose, ensureTranslatorPipeline };
console.log('[SodaTranslate] 模块已加载（' + MODEL_ID + ', webgpu+q4）');